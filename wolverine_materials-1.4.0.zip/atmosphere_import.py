# Builds a Blender world (sky box) and sun lamp from a Marvel's Wolverine .atmosphere file.
import math
import os
import re

import bpy
import numpy as np
from mathutils import Vector

from . import atmosphere, gamefiles, texture

WORLD_PREFIX = "Wolverine Sky "
SUN_PREFIX = "Wolverine Sun "


def atmosphere_label(path):
    name = gamefiles.normalize(path).rsplit("/", 1)[-1]
    return name[:-len(".atmosphere")] if name.endswith(".atmosphere") else name


def _image_pixels(img):
    w, h = img.size
    px = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(px)
    return px.reshape(h, w, 4)            # row 0 = bottom


def _load_image(path):
    img = bpy.data.images.load(path, check_existing=True)
    if not img.has_data:
        try:
            img.pixels[0]                  # images load lazily; this forces it
        except Exception:
            pass
    if img.size[0] == 0 or not img.has_data:
        raise RuntimeError("Blender could not read %s (BC6H HDR DDS files need Blender 4.2 or later)" % os.path.basename(path))
    for cs in ("Linear Rec.709", "Linear"):
        try:
            img.colorspace_settings.name = cs
            break
        except TypeError:
            pass
    return img


def _cube_to_equirect(face_imgs, height):
    """Six square faces (+X, -X, +Y, -Y, +Z, -Z in game axes, D3D layout) -> a 2:1 lat-long float image whose
    columns run like the 4:1 sky boxes (u * 360 = angle of atan2(z, x) in game space) and rows from bottom (down)
    to top (up)."""
    faces = [_image_pixels(i)[::-1] for i in face_imgs]          # row 0 = top, as the game stores them
    n = faces[0].shape[0]
    w = 2 * height
    v, u = np.mgrid[0:height, 0:w]
    az = (u + 0.5) / w * 2 * np.pi
    el = ((v + 0.5) / height - 0.5) * np.pi                      # row 0 = bottom = -90
    x, y, z = np.cos(el) * np.cos(az), np.sin(el), np.cos(el) * np.sin(az)
    # the cube sky textures are authored with Z the other way round: sampled like this their sun sits at the key
    # light's azimuth (e.g. atm_day_flurries_canada: 230 degrees), sampled straight it would sit at 130
    z = -z
    ax, ay, az_ = np.abs(x), np.abs(y), np.abs(z)
    out = np.zeros((height, w, 4), dtype=np.float32)
    out[..., 3] = 1
    # face, major-axis mask, (u, v) on the face, D3D cube conventions
    sel = [
        (0, (ax >= ay) & (ax >= az_) & (x > 0), -z / ax, -y / ax),
        (1, (ax >= ay) & (ax >= az_) & (x <= 0), z / ax, -y / ax),
        (2, (ay > ax) & (ay >= az_) & (y > 0), x / ay, z / ay),
        (3, (ay > ax) & (ay >= az_) & (y <= 0), x / ay, -z / ay),
        (4, (az_ > ax) & (az_ > ay) & (z > 0), x / az_, -y / az_),
        (5, (az_ > ax) & (az_ > ay) & (z <= 0), -x / az_, -y / az_),
    ]
    for f, m, fu, fv in sel:
        if not m.any():
            continue
        cx = np.clip(((fu[m] + 1) * 0.5 * n).astype(np.int64), 0, n - 1)
        cy = np.clip(((fv[m] + 1) * 0.5 * n).astype(np.int64), 0, n - 1)
        out[m] = faces[f][cy, cx]
    return out


def _sky_image(game, info, folder, overwrite, report_note):
    """(image, kind) for the atmosphere's sky texture, converted into folder. kind: 'hemisphere' or 'sphere'."""
    aid = info["sky"]
    if not aid:
        return None, None
    data = game.read_id(aid, 0)
    if data is None:
        report_note("sky texture %016x is not in the game files" % aid)
        return None, None
    head = texture.parse_header(data)
    kind = atmosphere.sky_kind(head)
    os.makedirs(folder, exist_ok=True)
    if kind in ("hemisphere", "sphere"):
        hd = game.read_id(aid, 1) if head["hd_len"] else None
        path = os.path.join(folder, "sky_%016x.dds" % aid)
        if overwrite or not os.path.isfile(path):
            dds, _info = texture.to_dds(data, hd)
            with open(path, "wb") as fh:
                fh.write(dds)
        return _load_image(path), kind
    if kind == "cube":
        path = os.path.join(folder, "sky_%016x_latlong.exr" % aid)
        if overwrite or not os.path.isfile(path):
            imgs = []
            for i, dds in enumerate(atmosphere.cube_faces(data)):
                fp = os.path.join(folder, "sky_%016x_face%d.dds" % (aid, i))
                with open(fp, "wb") as fh:
                    fh.write(dds)
                imgs.append(_load_image(fp))
            pix = _cube_to_equirect(imgs, max(256, min(2048, head["sd_width"])))
            for im in imgs:
                bpy.data.images.remove(im)
            h, w = pix.shape[:2]
            out = bpy.data.images.new(os.path.basename(path), w, h, alpha=False, float_buffer=True)
            out.pixels.foreach_set(pix.ravel())
            out.filepath_raw = path
            out.file_format = "OPEN_EXR"
            out.save()
            bpy.data.images.remove(out)
        return _load_image(path), "sphere"
    report_note("sky texture %016x has an unexpected shape (%dx%d)" % (aid, head["sd_width"], head["sd_height"]))
    return None, None


def _mean_radiance(img, kind):
    """Average sky radiance, weighted by solid angle, from a small copy of the image."""
    px = _image_pixels(img)[..., :3]
    h, w = px.shape[:2]
    step = max(1, w // 512)
    p = px[::step, ::step]
    rows = p.shape[0]
    if kind == "hemisphere":
        el = (np.arange(rows) + 0.5) / rows * (np.pi / 2)
    else:
        el = ((np.arange(rows) + 0.5) / rows - 0.5) * np.pi
    wgt = np.cos(el)[:, None]
    lum = p @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)
    return float((lum * wgt).sum() / (wgt.sum() * p.shape[1]))


def _node(tree, kind, loc, **inputs):
    n = tree.nodes.new(kind)
    n.location = loc
    for k, v in inputs.items():
        setattr(n, k, v)
    return n


def _math(tree, op, loc, a=None, b=None):
    n = tree.nodes.new("ShaderNodeMath")
    n.operation = op
    n.location = loc
    if a is not None and not hasattr(a, "is_linked"):
        n.inputs[0].default_value = a
    if b is not None and not hasattr(b, "is_linked"):
        n.inputs[1].default_value = b
    links = tree.links
    if hasattr(a, "is_linked"):
        links.new(a, n.inputs[0])
    if hasattr(b, "is_linked"):
        links.new(b, n.inputs[1])
    return n.outputs[0]


def build_world(name, img, kind, rotation_deg, strength, mirror=False):
    """World whose background samples the game's lat-long sky the way the game does."""
    world = bpy.data.worlds.get(WORLD_PREFIX + name) or bpy.data.worlds.new(WORLD_PREFIX + name)
    world.use_nodes = True
    tree = world.node_tree
    tree.nodes.clear()
    L = tree.links
    coord = _node(tree, "ShaderNodeTexCoord", (-1400, 0))
    sep = _node(tree, "ShaderNodeSeparateXYZ", (-1200, 0))
    L.new(coord.outputs["Generated"], sep.inputs[0])
    # Blender (x, y, z) = game (x, -z, y): game atan2(z, x) = atan2(-y, x), game height = z
    neg_y = _math(tree, "MULTIPLY", (-1000, 80), sep.outputs["Y"], -1.0)
    ang = _math(tree, "ARCTAN2", (-820, 80), neg_y, sep.outputs["X"])
    turns = _math(tree, "MULTIPLY", (-640, 80), ang, (-1.0 if mirror else 1.0) / (2 * math.pi))
    shifted = _math(tree, "SUBTRACT", (-460, 80), turns, rotation_deg / 360.0)
    u = _math(tree, "FRACT", (-280, 80), shifted)
    if kind == "hemisphere":
        absz = _math(tree, "ABSOLUTE", (-1000, -120), sep.outputs["Z"])     # the game mirrors the sky below the horizon
        el = _math(tree, "ARCSINE", (-820, -120), absz)
        v = _math(tree, "MULTIPLY", (-640, -120), el, 2.0 / math.pi)
    else:
        el = _math(tree, "ARCSINE", (-820, -120), sep.outputs["Z"])
        half = _math(tree, "MULTIPLY", (-640, -120), el, 1.0 / math.pi)
        v = _math(tree, "ADD", (-460, -120), half, 0.5)
    comb = _node(tree, "ShaderNodeCombineXYZ", (-100, 0))
    L.new(u, comb.inputs[0])
    L.new(v, comb.inputs[1])
    tex = _node(tree, "ShaderNodeTexImage", (100, 0))
    tex.image = img
    tex.extension = "EXTEND"
    tex.interpolation = "Linear"
    L.new(comb.outputs[0], tex.inputs["Vector"])
    bg = _node(tree, "ShaderNodeBackground", (400, 0))
    bg.inputs["Strength"].default_value = strength
    L.new(tex.outputs["Color"], bg.inputs["Color"])
    out = _node(tree, "ShaderNodeOutputWorld", (620, 0))
    L.new(bg.outputs[0], out.inputs["Surface"])
    return world


def build_flat_world(name, color, strength):
    world = bpy.data.worlds.get(WORLD_PREFIX + name) or bpy.data.worlds.new(WORLD_PREFIX + name)
    world.use_nodes = True
    tree = world.node_tree
    tree.nodes.clear()
    bg = _node(tree, "ShaderNodeBackground", (0, 0))
    bg.inputs["Color"].default_value = (color[0], color[1], color[2], 1.0)
    bg.inputs["Strength"].default_value = strength
    out = _node(tree, "ShaderNodeOutputWorld", (220, 0))
    tree.links.new(bg.outputs[0], out.inputs["Surface"])
    return world


def _remove_other_suns(keep_name):
    for ob in list(bpy.data.objects):
        if ob.name.startswith(SUN_PREFIX) and ob.name != keep_name and ob.type == "LIGHT":
            lamp = ob.data
            bpy.data.objects.remove(ob)
            if lamp is not None and lamp.users == 0:
                bpy.data.lights.remove(lamp)


def build_sun(context, name, info, strength_scale, mirror=False):
    _remove_other_suns(SUN_PREFIX + name)
    lamp = bpy.data.lights.get(SUN_PREFIX + name) or bpy.data.lights.new(SUN_PREFIX + name, "SUN")
    lamp.color = info["key_color"]
    lamp.energy = info["key_intensity"] * strength_scale
    lamp.angle = math.radians(0.53)
    ob = bpy.data.objects.get(SUN_PREFIX + name)
    if ob is None:
        ob = bpy.data.objects.new(SUN_PREFIX + name, lamp)
        context.scene.collection.objects.link(ob)
    az = -info["key_azimuth"] if mirror else info["key_azimuth"]
    toward_sun = Vector(atmosphere.game_to_blender_dir(atmosphere.sun_direction_game(az, info["key_elevation"])))
    # a sun lamp shines along its local -Z, so its +Z points at the sun
    ob.rotation_mode = "QUATERNION"
    ob.rotation_quaternion = toward_sun.to_track_quat("Z", "Y")
    ob.location = (0.0, 0.0, 10.0)
    return ob


def run_import(context, prefs, path_or_label, data, folder_root, report, add_sun=True, set_exposure=True,
               sky_strength=1.0, overwrite=False, mirror=False):
    try:
        info = atmosphere.parse(data)
    except atmosphere.AtmosphereError as e:
        report({"ERROR"}, "%s: %s" % (path_or_label, e))
        return None
    name = atmosphere_label(path_or_label)
    game_dir = bpy.path.abspath(prefs.game_folder.strip()) if prefs.game_folder.strip() else ""
    notes = []
    img = kind = None
    if info["sky"]:
        try:
            game = gamefiles.GameFolder(game_dir)
        except OSError as e:
            report({"ERROR"}, "Game folder: %s (the sky texture is read from it)" % e)
            return None
        try:
            folder = os.path.join(folder_root, "atmosphere", re.sub(r"[^A-Za-z0-9_.-]", "_", name))
            img, kind = _sky_image(game, info, folder, overwrite, notes.append)
        except (texture.TextureError, OSError, RuntimeError) as e:
            notes.append(str(e))
        finally:
            game.close()
    if img is not None:
        img.name = "%s sky" % name
        world = build_world(name, img, kind, info["sky_rotation"], sky_strength, mirror)
        mean = _mean_radiance(img, kind) * sky_strength
    else:
        # no sky box (some interiors and test atmospheres): a flat background in the key light's colour
        world = build_flat_world(name, info["key_color"], 0.05 * sky_strength)
        mean = 0.05 * sky_strength
        notes.append("no sky box texture; used a plain background")
    for k in ("key_intensity", "key_azimuth", "key_elevation", "key_softness", "sun_disc_azimuth_offset",
              "sun_disc_elevation_offset", "sky_rotation"):
        world["wolverine_" + k] = float(info[k])
    world["wolverine_key_color"] = list(info["key_color"])
    world["wolverine_atmosphere"] = path_or_label
    world["wolverine_mirrored"] = bool(mirror)
    world["wolverine_sky_texture"] = "%016x" % info["sky"] if info["sky"] else ""
    world["wolverine_sky_mean_radiance"] = mean
    context.scene.world = world
    if add_sun and info["key_intensity"] > 0:
        sun = build_sun(context, name, info, sky_strength, mirror)
    else:
        sun = None
        _remove_other_suns("")
    if set_exposure and mean > 0:
        # the game's values are physical-ish and its tone mapping brings them to screen range; set Blender's
        # exposure so the average sky lands a little below 1
        context.scene.view_settings.exposure = max(-10.0, min(10.0, -math.log2(mean) - 0.7))
    msg = "Atmosphere %s: sky %s, sun %s at azimuth %.0f, elevation %.0f" % (
        name, (kind or "none"), "%.3g" % info["key_intensity"] if sun else "off", info["key_azimuth"], info["key_elevation"])
    if set_exposure and mean > 0:
        msg += ", exposure %.2f" % context.scene.view_settings.exposure
    if notes:
        msg += " (" + "; ".join(notes) + ")"
    report({"INFO"}, msg)
    return world
