# Builds Blender node materials from parsed game materials.
#
# The game shades with a specular / gloss model:
#     _c  base colour (diffuse; black where the surface is metal)
#     _n  normal map, X and Y only (BC5); green points up, as Blender expects
#     _g  kind 3: R = gloss, G = specular level        kind 4: RGB = specular colour, A = gloss
# Blender's Principled BSDF is metal / roughness, so the node tree converts:
#     roughness = 1 - gloss * Glossiness
#     F0        = specular ^ 2.2                        (the texture stores it sRGB-encoded)
#     metallic  = F0 remapped from 0.08 .. 0.45
#     base      = mix(diffuse, F0 colour, metallic)
#     specular level (non-metals) = F0 / 0.08
import bpy

NORMAL_GROUP = 'Wolverine Normal XY'
SPEC_GROUP = 'Wolverine Specular Gloss'


def _socket(tree, name, in_out, kind):
    return tree.interface.new_socket(name=name, in_out=in_out, socket_type=kind)


def _math(tree, op, a=None, b=None, loc=(0, 0), clamp=False):
    n = tree.nodes.new('ShaderNodeMath')
    n.operation = op
    n.use_clamp = clamp
    n.location = loc
    for i, v in enumerate((a, b)):
        if v is None:
            continue
        if isinstance(v, (int, float)):
            n.inputs[i].default_value = v
        else:
            tree.links.new(v, n.inputs[i])
    return n.outputs[0]


def normal_group():
    """Colour (X, Y in red and green) -> colour with the blue channel rebuilt, ready for a Normal Map node."""
    g = bpy.data.node_groups.get(NORMAL_GROUP)
    if g:
        return g
    g = bpy.data.node_groups.new(NORMAL_GROUP, 'ShaderNodeTree')
    _socket(g, 'Color', 'INPUT', 'NodeSocketColor')
    _socket(g, 'Color', 'OUTPUT', 'NodeSocketColor')
    gin = g.nodes.new('NodeGroupInput'); gin.location = (-700, 0)
    gout = g.nodes.new('NodeGroupOutput'); gout.location = (500, 0)
    sep = g.nodes.new('ShaderNodeSeparateColor'); sep.location = (-520, 0)
    g.links.new(gin.outputs[0], sep.inputs[0])
    x = _math(g, 'MULTIPLY_ADD', sep.outputs[0], 2.0, (-340, 120)); x.node.inputs[2].default_value = -1.0
    y = _math(g, 'MULTIPLY_ADD', sep.outputs[1], 2.0, (-340, -60)); y.node.inputs[2].default_value = -1.0
    xx = _math(g, 'MULTIPLY', x, x, (-160, 120))
    yy = _math(g, 'MULTIPLY', y, y, (-160, -60))
    s = _math(g, 'ADD', xx, yy, (0, 30))
    one_minus = _math(g, 'SUBTRACT', 1.0, s, (150, 30), clamp=True)
    z = _math(g, 'SQRT', one_minus, None, (300, 30))
    zc = _math(g, 'MULTIPLY_ADD', z, 0.5, (300, -130)); zc.node.inputs[2].default_value = 0.5
    comb = g.nodes.new('ShaderNodeCombineColor'); comb.location = (300, 200)
    g.links.new(sep.outputs[0], comb.inputs[0])
    g.links.new(sep.outputs[1], comb.inputs[1])
    g.links.new(zc, comb.inputs[2])
    g.links.new(comb.outputs[0], gout.inputs[0])
    return g


def spec_group():
    """Diffuse + specular colour + gloss -> Principled inputs."""
    g = bpy.data.node_groups.get(SPEC_GROUP)
    if g:
        return g
    g = bpy.data.node_groups.new(SPEC_GROUP, 'ShaderNodeTree')
    _socket(g, 'Diffuse', 'INPUT', 'NodeSocketColor').default_value = (0.5, 0.5, 0.5, 1)
    _socket(g, 'Specular', 'INPUT', 'NodeSocketColor').default_value = (0.22, 0.22, 0.22, 1)
    gl = _socket(g, 'Gloss', 'INPUT', 'NodeSocketFloat'); gl.default_value = 0.3; gl.min_value = 0; gl.max_value = 1
    gs = _socket(g, 'Glossiness', 'INPUT', 'NodeSocketFloat'); gs.default_value = 1.0; gs.min_value = 0; gs.max_value = 4
    _socket(g, 'Base Color', 'OUTPUT', 'NodeSocketColor')
    _socket(g, 'Metallic', 'OUTPUT', 'NodeSocketFloat')
    _socket(g, 'Roughness', 'OUTPUT', 'NodeSocketFloat')
    _socket(g, 'Specular Level', 'OUTPUT', 'NodeSocketFloat')
    gin = g.nodes.new('NodeGroupInput'); gin.location = (-900, 0)
    gout = g.nodes.new('NodeGroupOutput'); gout.location = (500, 0)
    gamma = g.nodes.new('ShaderNodeGamma'); gamma.location = (-700, -80); gamma.inputs[1].default_value = 2.2
    g.links.new(gin.outputs['Specular'], gamma.inputs[0])
    sep = g.nodes.new('ShaderNodeSeparateColor'); sep.location = (-520, -80)
    g.links.new(gamma.outputs[0], sep.inputs[0])
    m1 = _math(g, 'MAXIMUM', sep.outputs[0], sep.outputs[1], (-340, -80))
    f0 = _math(g, 'MAXIMUM', m1, sep.outputs[2], (-180, -80))
    rng = g.nodes.new('ShaderNodeMapRange'); rng.location = (0, 60); rng.clamp = True
    rng.inputs['From Min'].default_value = 0.08
    rng.inputs['From Max'].default_value = 0.45
    g.links.new(f0, rng.inputs['Value'])
    mix = g.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.location = (220, 260)
    g.links.new(rng.outputs['Result'], mix.inputs[0])       # Factor
    g.links.new(gin.outputs['Diffuse'], mix.inputs[6])      # A (colour)
    g.links.new(gamma.outputs[0], mix.inputs[7])            # B (colour)
    gloss = _math(g, 'MULTIPLY', gin.outputs['Gloss'], gin.outputs['Glossiness'], (-340, -300), clamp=True)
    rough = _math(g, 'SUBTRACT', 1.0, gloss, (-160, -300), clamp=True)
    level = _math(g, 'DIVIDE', f0, 0.08, (0, -160), clamp=True)
    g.links.new(mix.outputs[2], gout.inputs['Base Color'])
    g.links.new(rng.outputs['Result'], gout.inputs['Metallic'])
    g.links.new(rough, gout.inputs['Roughness'])
    g.links.new(level, gout.inputs['Specular Level'])
    return g


def _image_node(tree, image, label, loc, non_color):
    n = tree.nodes.new('ShaderNodeTexImage')
    n.image = image
    n.label = label
    n.location = loc
    if image is not None:
        try:
            image.colorspace_settings.name = 'Non-Color' if non_color else 'sRGB'
        except TypeError:
            pass
    return n


def build(mat, images, glossiness=1.0, tint=(1.0, 1.0, 1.0), use_alpha=False, skin=False, extra=()):
    """images: {'color': (image, info), 'normal': ..., 'gloss': ..., 'alpha': ...} (any may be missing).
    extra: [(label, image, info)] loaded but left unconnected."""
    if not mat.node_tree:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new('ShaderNodeOutputMaterial'); out.location = (500, 0)
    bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled'); bsdf.location = (200, 0)
    tree.links.new(bsdf.outputs[0], out.inputs[0])
    conv = tree.nodes.new('ShaderNodeGroup'); conv.node_tree = spec_group(); conv.location = (-80, 0)
    conv.label = 'Specular / gloss to metal / roughness'
    conv.inputs['Glossiness'].default_value = glossiness
    tree.links.new(conv.outputs['Base Color'], bsdf.inputs['Base Color'])
    tree.links.new(conv.outputs['Metallic'], bsdf.inputs['Metallic'])
    tree.links.new(conv.outputs['Roughness'], bsdf.inputs['Roughness'])
    if 'Specular IOR Level' in bsdf.inputs:
        tree.links.new(conv.outputs['Specular Level'], bsdf.inputs['Specular IOR Level'])

    color = images.get('color')
    tinted = any(abs(c - 1.0) > 1e-4 for c in tint)
    if color:
        n = _image_node(tree, color[0], 'Base colour (_c)', (-460, 300), not color[1]['srgb'])
        if tinted:
            mul = tree.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'
            mul.location = (-270, 300); mul.label = 'DiffuseColor tint'
            mul.inputs[0].default_value = 1.0
            mul.inputs[7].default_value = (tint[0], tint[1], tint[2], 1.0)
            tree.links.new(n.outputs['Color'], mul.inputs[6])
            tree.links.new(mul.outputs[2], conv.inputs['Diffuse'])
        else:
            tree.links.new(n.outputs['Color'], conv.inputs['Diffuse'])
        if use_alpha:
            tree.links.new(n.outputs['Alpha'], bsdf.inputs['Alpha'])
    elif tinted:
        conv.inputs['Diffuse'].default_value = (tint[0], tint[1], tint[2], 1.0)
    gloss = images.get('gloss')
    if gloss:
        n = _image_node(tree, gloss[0], 'Gloss / specular (_g)', (-460, 0), True)
        if gloss[1]['kind'] == 4:                       # RGB = specular colour, A = gloss
            tree.links.new(n.outputs['Color'], conv.inputs['Specular'])
            tree.links.new(n.outputs['Alpha'], conv.inputs['Gloss'])
        else:                                           # R = gloss, G = specular level
            sep = tree.nodes.new('ShaderNodeSeparateColor'); sep.location = (-270, -40)
            comb = tree.nodes.new('ShaderNodeCombineColor'); comb.location = (-270, -200)
            tree.links.new(n.outputs['Color'], sep.inputs[0])
            for i in range(3):
                tree.links.new(sep.outputs[1], comb.inputs[i])
            tree.links.new(comb.outputs[0], conv.inputs['Specular'])
            tree.links.new(sep.outputs[0], conv.inputs['Gloss'])
            conv.location = (-80, 60)
    normal = images.get('normal')
    if normal:
        n = _image_node(tree, normal[0], 'Normal (_n)', (-760, -340), True)
        fix = tree.nodes.new('ShaderNodeGroup'); fix.node_tree = normal_group(); fix.location = (-460, -340)
        nm = tree.nodes.new('ShaderNodeNormalMap'); nm.location = (-270, -340)
        tree.links.new(n.outputs['Color'], fix.inputs[0])
        tree.links.new(fix.outputs[0], nm.inputs['Color'])
        tree.links.new(nm.outputs['Normal'], bsdf.inputs['Normal'])
    alpha = images.get('alpha')
    if alpha:
        if alpha[1].get('channel') == 'A':
            n = _image_node(tree, alpha[0], 'Strand opacity (_x alpha)', (-460, 600), True)
            tree.links.new(n.outputs['Alpha'], bsdf.inputs['Alpha'])
        else:
            n = _image_node(tree, alpha[0], 'Alpha (_a)', (-460, 600), True)
            tree.links.new(n.outputs['Color'], bsdf.inputs['Alpha'])
        use_alpha = True
    if skin and 'Subsurface Weight' in bsdf.inputs:
        bsdf.inputs['Subsurface Weight'].default_value = 0.15
        bsdf.inputs['Subsurface Radius'].default_value = (1.0, 0.35, 0.2)
        bsdf.inputs['Subsurface Scale'].default_value = 0.01
    if use_alpha and hasattr(mat, 'surface_render_method'):
        mat.surface_render_method = 'DITHERED'
    y = 300
    for label, image, info in extra:
        _image_node(tree, image, label, (-1100, y), not info['srgb'])
        y -= 290
    if extra:
        frame = tree.nodes.new('NodeFrame')
        frame.label = 'Other textures of this material (not connected)'
        for n in tree.nodes:
            if n.type == 'TEX_IMAGE' and n.location.x < -1000:
                n.parent = frame


def hair_standin(mat, color):
    """A plain hair-coloured surface with fine streaks, for a hair wrap mesh shown in place of hair the
    model file does not contain."""
    if not mat.node_tree:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new('ShaderNodeOutputMaterial'); out.location = (500, 0)
    bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled'); bsdf.location = (200, 0)
    tree.links.new(bsdf.outputs[0], out.inputs[0])
    bsdf.inputs['Roughness'].default_value = 0.45
    # streaks: noise stretched along one axis, darkening the colour a little in places
    coord = tree.nodes.new('ShaderNodeTexCoord'); coord.location = (-900, 0)
    mapping = tree.nodes.new('ShaderNodeMapping'); mapping.location = (-700, 0)
    mapping.inputs['Scale'].default_value = (60.0, 60.0, 4.0)
    noise = tree.nodes.new('ShaderNodeTexNoise'); noise.location = (-500, 0)
    noise.inputs['Scale'].default_value = 4.0
    noise.inputs['Detail'].default_value = 4.0
    ramp = tree.nodes.new('ShaderNodeMapRange'); ramp.location = (-300, 0)
    ramp.inputs['To Min'].default_value = 0.6
    ramp.inputs['To Max'].default_value = 1.25
    mul = tree.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'
    mul.location = (-80, 100); mul.inputs[0].default_value = 1.0
    mul.inputs[6].default_value = (color[0], color[1], color[2], 1.0)
    tree.links.new(coord.outputs['Object'], mapping.inputs['Vector'])
    tree.links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
    tree.links.new(noise.outputs['Fac'], ramp.inputs['Value'])
    tree.links.new(ramp.outputs['Result'], mul.inputs[7])
    tree.links.new(mul.outputs[2], bsdf.inputs['Base Color'])
    if hasattr(mat, 'surface_render_method'):
        mat.surface_render_method = 'DITHERED'
    mat.diffuse_color = (color[0], color[1], color[2], 1.0)


# ---------------------------------------------------------------------------- heads: hair-covered skin

def _small_pixels(image, size=48):
    """RGBA floats of a small copy of the image (row-major, bottom row first), or None."""
    if image is None:
        return None
    try:
        tmp = image.copy()
        tmp.scale(size, size)
        px = list(tmp.pixels[:])
        bpy.data.images.remove(tmp)
        return px
    except Exception:
        return None


def _to_linear(v):
    return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4


def _lum(r, g, b):
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def skin_tone(color_image, mask_image=None):
    """Linear colour of the bare skin: the median of the brighter part of the colour texture (scalp and beard
    are painted dark, so the bright part is skin)."""
    c = _small_pixels(color_image, 64)
    if not c:
        return (0.28, 0.15, 0.10)
    srgb = color_image.colorspace_settings.name.lower().startswith('srgb') and not color_image.is_float
    px = []
    for i in range(0, len(c), 4):
        r, g, b = c[i], c[i + 1], c[i + 2]
        if srgb:
            r, g, b = _to_linear(r), _to_linear(g), _to_linear(b)
        px.append((_lum(r, g, b), r, g, b))
    px.sort()
    top = px[int(len(px) * 0.6):]
    if len(top) < 20 or top[len(top) // 2][0] < 0.02:
        return (0.28, 0.15, 0.10)
    tone = tuple(sorted(p[k] for p in top)[len(top) // 2] for k in (1, 2, 3))
    return tone


def hair_covered_skin(mat, mask_image, hair_color, skin_color, strength=0.9):
    """The head textures paint the skin under the scalp and beard almost black: in the game that area is covered
    by strands and a scalp layer drawn in the hair colour. This lifts it to a mix of skin and hair colour, keeping
    the texture's own detail. Where: the parts of the colour texture much darker than the skin. The head mask's
    blue channel (cavities) keeps nostrils, ear holes and the mouth corner untouched."""
    tree = mat.node_tree
    if tree is None:
        return False
    conv = next((n for n in tree.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name.startswith(SPEC_GROUP)), None)
    if conv is None or not conv.inputs['Diffuse'].is_linked:
        return False
    src = conv.inputs['Diffuse'].links[0].from_socket
    s_lum = max(0.03, _lum(*skin_color[:3]))
    bw = tree.nodes.new('ShaderNodeRGBToBW'); bw.location = (-560, 460)
    tree.links.new(src, bw.inputs[0])
    region = tree.nodes.new('ShaderNodeMapRange'); region.location = (-380, 620); region.clamp = True
    region.label = 'Hair coverage (dark paint)'
    region.interpolation_type = 'SMOOTHSTEP'
    region.inputs['From Min'].default_value = s_lum * 0.8
    region.inputs['From Max'].default_value = s_lum * 0.3
    tree.links.new(bw.outputs[0], region.inputs['Value'])
    cover = region.outputs['Result']
    if mask_image is not None:
        mask = _image_node(tree, mask_image, 'Cavities (_m blue)', (-760, 800), True)
        sep = tree.nodes.new('ShaderNodeSeparateColor'); sep.location = (-560, 800)
        tree.links.new(mask.outputs['Color'], sep.inputs[0])
        cav = tree.nodes.new('ShaderNodeMapRange'); cav.location = (-380, 800); cav.clamp = True
        cav.label = 'Keep cavities'
        cav.inputs['From Min'].default_value = 0.35
        cav.inputs['From Max'].default_value = 0.7
        tree.links.new(sep.outputs[2], cav.inputs['Value'])
        cover = _math(tree, 'MULTIPLY', cover, cav.outputs['Result'], (-200, 720))
    cover = _math(tree, 'MULTIPLY', cover, strength, (-200, 620), clamp=True)
    # target: mostly hair colour with some skin showing through, modulated by the painted detail (stubble)
    target_col = tuple(0.4 * s + 0.6 * h for s, h in zip(skin_color, hair_color))
    detail = tree.nodes.new('ShaderNodeMapRange'); detail.location = (-380, 460); detail.clamp = True
    detail.label = 'Keep painted detail'
    detail.inputs['From Min'].default_value = 0.0
    detail.inputs['From Max'].default_value = s_lum * 0.1
    detail.inputs['To Min'].default_value = 0.7
    detail.inputs['To Max'].default_value = 1.0
    tree.links.new(bw.outputs[0], detail.inputs['Value'])
    tgt = tree.nodes.new('ShaderNodeMix'); tgt.data_type = 'RGBA'; tgt.blend_type = 'MULTIPLY'
    tgt.location = (-200, 460); tgt.inputs[0].default_value = 1.0
    tgt.inputs[6].default_value = (target_col[0], target_col[1], target_col[2], 1.0)
    tree.links.new(detail.outputs['Result'], tgt.inputs[7])
    mix = tree.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.blend_type = 'LIGHTEN'
    mix.location = (-60, 380); mix.label = 'Lighten hair-covered skin'   # only ever raises the dark paint
    tree.links.new(cover, mix.inputs[0])
    tree.links.new(src, mix.inputs[6])
    tree.links.new(tgt.outputs[2], mix.inputs[7])
    tree.links.new(mix.outputs[2], conv.inputs['Diffuse'])
    return True


# ---------------------------------------------------------------------------- hair cards

def hair_cards(mat, hair_color, opacity_image, opacity_channel, strand_image=None, gloss=0.6):
    """Hair cards shaded closer to the game: the hair colour darkens towards the root and lightens towards the
    tip (red of the "_x" texture is 1 at the root), strands vary a little in brightness (its green), and the
    opacity is sharpened so strands read as strands instead of a soft haze."""
    if not mat.node_tree:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new('ShaderNodeOutputMaterial'); out.location = (700, 0)
    bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled'); bsdf.location = (400, 0)
    tree.links.new(bsdf.outputs[0], out.inputs[0])
    bsdf.inputs['Roughness'].default_value = max(0.25, min(0.6, 1.0 - 0.55 * gloss))
    if 'Specular IOR Level' in bsdf.inputs:
        bsdf.inputs['Specular IOR Level'].default_value = 0.6
    if 'Sheen Weight' in bsdf.inputs:
        bsdf.inputs['Sheen Weight'].default_value = 0.25
        bsdf.inputs['Sheen Roughness'].default_value = 0.4
    if 'Coat Weight' in bsdf.inputs:
        bsdf.inputs['Coat Weight'].default_value = 0.0
    if 'Subsurface Weight' in bsdf.inputs:
        bsdf.inputs['Subsurface Weight'].default_value = 0.05
        bsdf.inputs['Subsurface Radius'].default_value = (0.4, 0.25, 0.15)
        bsdf.inputs['Subsurface Scale'].default_value = 0.005
    base = tree.nodes.new('ShaderNodeRGB'); base.location = (-500, 300); base.label = 'Hair colour'
    base.outputs[0].default_value = (hair_color[0], hair_color[1], hair_color[2], 1.0)
    col = base.outputs[0]
    if strand_image is not None:
        x = _image_node(tree, strand_image, 'Root / strand variation (_x)', (-900, 100), True)
        sep = tree.nodes.new('ShaderNodeSeparateColor'); sep.location = (-700, 100)
        tree.links.new(x.outputs['Color'], sep.inputs[0])
        root = tree.nodes.new('ShaderNodeMapRange'); root.location = (-500, 120); root.clamp = True
        root.label = 'Root (dark) to tip (light)'
        root.inputs['To Min'].default_value = 1.35          # tip
        root.inputs['To Max'].default_value = 0.6           # root
        tree.links.new(sep.outputs[0], root.inputs['Value'])
        var = tree.nodes.new('ShaderNodeMapRange'); var.location = (-500, -60); var.clamp = True
        var.label = 'Per-strand variation'
        var.inputs['To Min'].default_value = 0.82
        var.inputs['To Max'].default_value = 1.18
        tree.links.new(sep.outputs[1], var.inputs['Value'])
        f = _math(tree, 'MULTIPLY', root.outputs['Result'], var.outputs['Result'], (-300, 40))
        mul = tree.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'
        mul.location = (-120, 200); mul.inputs[0].default_value = 1.0
        tree.links.new(col, mul.inputs[6])
        comb = tree.nodes.new('ShaderNodeCombineColor'); comb.location = (-300, -120)
        for i in range(3):
            tree.links.new(f, comb.inputs[i])
        tree.links.new(comb.outputs[0], mul.inputs[7])
        col = mul.outputs[2]
    tree.links.new(col, bsdf.inputs['Base Color'])
    if opacity_image is not None:
        a = _image_node(tree, opacity_image, 'Strand opacity', (-500, -360), True)
        src = a.outputs['Alpha'] if opacity_channel == 'A' else a.outputs['Color']
        if opacity_channel != 'A':
            bw = tree.nodes.new('ShaderNodeRGBToBW'); bw.location = (-300, -360)
            tree.links.new(src, bw.inputs[0]); src = bw.outputs[0]
        sharp = tree.nodes.new('ShaderNodeMapRange'); sharp.location = (-100, -360); sharp.clamp = True
        sharp.label = 'Sharpen strands'
        sharp.inputs['From Min'].default_value = 0.12
        sharp.inputs['From Max'].default_value = 0.7
        tree.links.new(src, sharp.inputs['Value'])
        tree.links.new(sharp.outputs['Result'], bsdf.inputs['Alpha'])
    if hasattr(mat, 'surface_render_method'):
        mat.surface_render_method = 'DITHERED'
    mat.use_backface_culling = False
    mat.diffuse_color = (hair_color[0], hair_color[1], hair_color[2], 1.0)
