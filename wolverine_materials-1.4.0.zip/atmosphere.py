# Marvel's Wolverine (PS5, i38) .atmosphere files. No Blender needed.
#
# An atmosphere is a DAT1 file whose section 0x02F06D4E holds the 2824-byte block the game copies straight
# into its Atmosphere object (eboot.bin loads it with one memcpy, then resolves the asset references in it).
# The values read here and where they sit in that block:
#
#   0x020  sky box texture       (asset reference: u64 id, 12 bytes of runtime space, u32 type 0x95A3A227)
#   0x038  default environment probe texture (a cube map baked from this sky)
#   0x050  key light colour      3 x f32 (linear RGB)
#   0x05C  key light intensity   f32, same units as the sky texture
#   0x060  key light azimuth     f32 degrees
#   0x064  key light elevation   f32 degrees
#   0x068  key light softness    f32
#   0x06C  sun disc azimuth offset   f32 degrees
#   0x070  sun disc elevation offset f32 degrees
#   0x0F0  sky box azimuth rotation  f32 degrees
#
# Directions, in game space (Y up, as models and zones are stored):
#   key light:  (cos el * cos az,  sin el,  cos el * sin az)
#   sky box:    a lat-long image; column u covers azimuth (u * 360 + rotation) measured the same way, the bottom
#               row is the horizon and the top row the zenith when it is 4:1 (the game mirrors it below the
#               horizon); 2:1 images cover the whole sphere. Square sky textures are cube maps (6 faces).
# These were checked against each atmosphere's baked environment probe: the probe's cube faces line up with the
# sky texture placed this way (correlation 0.92), and the brightest part of the sky sits at the key light azimuth.
import math
import struct

from . import texture

SECTION = 0x02F06D4E
TEXTURE_TYPE = 0x95A3A227
BLOCK_SIZE = 0xB08


class AtmosphereError(Exception):
    pass


def _sections(data):
    base = texture.unwrap(data)
    d = data[base:]
    if d[:4] != b'1TAD':
        raise AtmosphereError('not a DAT1 file')
    count = struct.unpack_from('<H', d, 12)[0]
    out = {}
    for k in range(count):
        tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
        out[tag] = (off, size)
    return d, out


def parse(data):
    """Values of an .atmosphere file (as read from the game or exported with DAT1GUI)."""
    try:
        d, secs = _sections(data)
    except texture.TextureError:
        raise AtmosphereError('not a DAT1 file')
    if SECTION not in secs:
        raise AtmosphereError('no atmosphere block in this file')
    off, size = secs[SECTION]
    if size < BLOCK_SIZE or off + size > len(d):
        raise AtmosphereError('the atmosphere block is shorter than expected')
    b = d[off:off + size]

    def f(o, n=1):
        v = struct.unpack_from('<%df' % n, b, o)
        return v if n > 1 else v[0]

    def ref(o):
        aid, = struct.unpack_from('<Q', b, o)
        return aid or None

    return {
        'sky': ref(0x20),
        'probe': ref(0x38),
        'key_color': tuple(max(0.0, c) for c in f(0x50, 3)),
        'key_intensity': max(0.0, f(0x5C)),
        'key_azimuth': f(0x60),
        'key_elevation': f(0x64),
        'key_softness': f(0x68),
        'sun_disc_azimuth_offset': f(0x6C),
        'sun_disc_elevation_offset': f(0x70),
        'sky_rotation': f(0xF0),
    }


def sun_direction_game(az_deg, el_deg):
    az, el = math.radians(az_deg), math.radians(el_deg)
    return (math.cos(el) * math.cos(az), math.sin(el), math.cos(el) * math.sin(az))


def game_to_blender_dir(v):
    x, y, z = v
    return (x, -z, y)


def sky_kind(head):
    """'hemisphere' (4:1), 'sphere' (2:1), 'cube' (6 square faces) or None."""
    w, h = head['sd_width'], head['sd_height']
    if w == 4 * h:
        return 'hemisphere'
    if w == 2 * h:
        return 'sphere'
    if w == h:
        return 'cube'
    return None


def cube_faces(texture_file):
    """The six faces (+X, -X, +Y, -Y, +Z, -Z, game axes) of a cube-map texture as single-mip DDS files.
    Each face is stored as its own full mip chain, smallest mip first, the way top_mip reads one 2D texture."""
    head = texture.parse_header(texture_file)
    fmt = head['format']
    if fmt not in texture.BLOCK_BYTES:
        raise texture.TextureError('pixel format %s is not supported' % texture.FORMAT_NAMES.get(fmt, fmt))
    bpb = texture.BLOCK_BYTES[fmt]
    w = h = head['sd_width']
    levels = head['sd_mips']
    data = head['sd_data']
    per = len(data) // 6
    unit_w = 16 if bpb == 16 else 32
    sizes = []
    for i in range(levels):
        mw, mh = max(w >> i, 1), max(h >> i, 1)
        wb, hb = (mw + 3) // 4, (mh + 3) // 4
        in_tail = levels > 1 and wb * hb * bpb <= 2048 and wb < unit_w   # a mip a whole tile wide gets its own 4 KB unit
        sizes.append((wb, hb, ((wb + unit_w - 1) // unit_w) * ((hb + 15) // 16) * texture.TAIL_BLOCK, in_tail))
    skip = (texture.TAIL_BLOCK if any(s[3] for s in sizes) else 0) + sum(s[2] for s in sizes[1:] if not s[3])
    wb, hb = sizes[0][0], sizes[0][1]
    faces = []
    for face in range(6):
        start = face * per + skip
        raw = texture._untile(data[start:start + sizes[0][2]], wb, hb, bpb)
        faces.append(texture.dds_bytes(fmt, w, h, raw))
    return faces


# Every .atmosphere in the game (from DAT1GUI's hashes.txt), so the importer can list them without it.
KNOWN = (
    'atmosphere/atm_dark_forest_institute_nightmare/atm_dark_forest_institute_nightmare.atmosphere',
    'atmosphere/atm_dawn_cloudy_sky_563/atm_dawn_cloudy_sky_563.atmosphere',
    'atmosphere/atm_Dawn_cloudy_sky_563/atm_dawn_cloudy_sky_563_CINE.atmosphere',
    'atmosphere/atm_dawn_cloudy_sky_563/atm_DOCKS_dawn_overcast.atmosphere',
    'atmosphere/atm_dawn_cloudy_sky_563/atm_docks_dawn_overcast_surveillance_photos_cine.atmosphere',
    'atmosphere/atm_dawn_cloudy_sky_563/atm_noon_cloudy_sky_563.atmosphere',
    'atmosphere/atm_Day_fluffyclouds_3_i30_029/atm_day_late_wispy_clouds_wa0196.atmosphere',
    'atmosphere/atm_day_flurries_canada/atm_day_flurries_canada.atmosphere',
    'atmosphere/atm_day_flurries_canada/atm_day_flurries_canada_institute_0100_homecoming_str.atmosphere',
    'atmosphere/atm_day_flurries_canada/atm_day_flurries_canada_institute_1.atmosphere',
    'atmosphere/atm_day_latenoon_fl0614/atm_day_latenoon_trask_fl0614.atmosphere',
    'atmosphere/atm_healing_winter_sunset/atm_healing_winter_sunset.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_beautiful_corner_dusk.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_beautiful_corner_sunrise.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_essexboss_night.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_night.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_night_Menu.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_night_OptimSun.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_night_projectx.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_night_storm.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_shinjuku_dawn.atmosphere',
    'atmosphere/atm_japan_night/atm_japan_ShinJuku_day.atmosphere',
    'atmosphere/atm_japan_night/atm_madripoor_day.atmosphere',
    'atmosphere/atm_japan_night/atm_madripoor_dusk.atmosphere',
    'atmosphere/atm_japan_night/atm_madripoor_sunset_03.atmosphere',
    'atmosphere/atm_jpn_landing_motorcycle_night/atm_jpn_landing_motorcycle_night.atmosphere',
    'atmosphere/atm_jpn_landing_motorcycle_night/atm_jpn_landing_motorcycle_night_Cine.atmosphere',
    'atmosphere/atm_jpn_landing_motorcycle_night/atm_jpn_landing_motorcycle_night_cine_Vista.atmosphere',
    'atmosphere/atm_jpn_landing_motorcycle_night/atm_jpn_landing_motorcycle_night_crash_cine.atmosphere',
    'atmosphere/atm_jpn_landing_motorcycle_night/atm_jpn_landing_motorcycle_night_plane_cine_red.atmosphere',
    'atmosphere/atm_lighting_basic_black/atm_lighting_basic_black.atmosphere',
    'atmosphere/atm_madripoor_present_night/atm_Epilogue_night.atmosphere',
    'atmosphere/atm_madripoor_present_night/atm_fortress_night.atmosphere',
    'atmosphere/atm_madripoor_present_night/atm_madrihome_0600_boatlaunch.atmosphere',
    'atmosphere/atm_madripoor_present_night/atm_madripoor_present_night.atmosphere',
    'atmosphere/atm_madripoor_present_night/atm_madripoor_present_night_Overlook_Cine.atmosphere',
    'atmosphere/atm_madripoor_present_night_wheel_ph/atm_madripoor_present_night_wheel_grand_adventure_cine.atmosphere',
    'atmosphere/atm_madripoor_present_night_wheel_ph/atm_madripoor_present_night_wheel_grand_adventure_cine_Openingshot.atmosphere',
    'atmosphere/atm_madripoor_present_night_WHEEL_ph/atm_madripoor_present_night_WHEEL_ph.atmosphere',
    'atmosphere/atm_MAD_Fallen_sunrise_oc/atm_MAD_Fallen_sunrise_oc.atmosphere',
    'atmosphere/atm_mad_fallen_sunrise_oc/atm_mad_fallen_sunrise_oc_projectx_exterior.atmosphere',
    'atmosphere/atm_mad_fallen_sunrise_oc/atm_mad_fallen_sunrise_oc_projectx_exterior_flying.atmosphere',
    'atmosphere/atm_mad_fallen_sunrise_oc/atm_mad_fallen_sunrise_oc_projectx_interior.atmosphere',
    'atmosphere/atm_mad_lowtownatk_dawn/atm_mad_lowtownatk_dawn.atmosphere',
    'atmosphere/atm_mad_lowtownatk_dawn/atm_mad_newworld_dawn.atmosphere',
    'atmosphere/atm_mad_rnd_dawn/atm_mad_rnd_dawn.atmosphere',
    'atmosphere/atm_MAD_RND_sunset/atm_MAD_RND_sunset.atmosphere',
    'atmosphere/atm_MAD_trask_campus_dawn/atm_MAD_trask_campus_dawn.atmosphere',
    'atmosphere/atm_MAD_Wheel_River_Dawn/atm_MAD_Wheel_River_Dawn.atmosphere',
    'atmosphere/atm_main_night_madripoor/atm_main_night_madripoor.atmosphere',
    'atmosphere/atm_master_dusk/atm_fortress_dusk.atmosphere',
    'atmosphere/atm_master_night_cloudy/atm_030_institute_0300_doors_str.atmosphere',
    'atmosphere/atm_master_night_cloudy/atm_healingwinter_night_cloudy_cabin_cine_v4.atmosphere',
    'atmosphere/atm_master_night_cloudy/atm_healingwinter_night_cloudy_cabin_v2.atmosphere',
    'atmosphere/atm_master_night_cloudy/atm_healingwinter_night_cloudy_cabin_v3.atmosphere',
    'atmosphere/atm_master_night_cloudy/atm_healingwinter_night_cloudy_cabin_wrt.atmosphere',
    'atmosphere/atm_MASTER_noon_cloudy/atm_refinery_noon_cloudy_LEVEL.atmosphere',
    'atmosphere/atm_master_noon_cloudy/atm_refinery_noon_cloudy_level_updated.atmosphere',
    'atmosphere/atm_master_overcast_storm/atm_japan_beautifulcorner_overcast_storm_3.atmosphere',
    'atmosphere/atm_master_overcast_storm/atm_madripoor_overcast_02.atmosphere',
    'atmosphere/atm_master_sunset_madripoor/atm_fortress_diorama_sunset_refinery_OptimSun.atmosphere',
    'atmosphere/atm_master_sunset_madripoor/atm_sunset_clear_sky_717.atmosphere',
    'atmosphere/atm_Nightmare_dark_forest.atmosphere',
    'atmosphere/atm_nightmare_end_atmosphere.atmosphere',
    'atmosphere/atm_rebirth_apocalypse_atmosphere.atmosphere',
    'atmosphere/atm_rebirth_cool_atmosphere.atmosphere',
    'atmosphere/atm_rebirth_warm_atmosphere.atmosphere',
    'atmosphere/atm_rebirth_warm_opening_cine_atmosphere.atmosphere',
    'atmosphere/atm_rebirth_warm_startmenu.atmosphere',
    'atmosphere/atm_sunset_fluffyclouds_3_i30_434/atm_065_institutetwo_0050_sightseeing_str.atmosphere',
    'atmosphere/atm_sunset_fluffyclouds_3_i30_434/atm_INS_sunset_fluffyclouds.atmosphere',
    'atmosphere/atm_sunset_fluffyclouds_3_i30_434/atm_sunset_fluffyclouds_3_i30_422_CABIN.atmosphere',
    'atmosphere/atm_sunset_fluffyclouds_3_i30_434/atm_sunset_fluffyclouds_3_i30_422_INSTITUTE.atmosphere',
    'atmosphere/atm_Telambang_day/atm_Telambang_day.atmosphere',
    'atmosphere/atm_telambang_night/atm_telambang_arkady_fight.atmosphere',
    'atmosphere/atm_telambang_night/atm_telambang_night.atmosphere',
    'atmosphere/atm_telambang_night/atm_telambang_night_cinemoon_2.atmosphere',
    'atmosphere/atm_telambang_night/atm_telambang_night_cine_moon.atmosphere',
    'atmosphere/atm_telambang_night/atm_telambang_night_unoptimized.atmosphere',
    'atmosphere/atm_test_night_cloudy/atm_test_night_cloudy_snow.atmosphere',
    'atmosphere/atm_UI_pause_menu/atm_UI_pause_menu.atmosphere',
    'atmosphere/character/atm_char_rom_heads_green.atmosphere',
)
