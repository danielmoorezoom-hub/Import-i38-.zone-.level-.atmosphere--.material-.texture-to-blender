# Marvel's Wolverine (PS5, i38) levels: .zone placement data and static .model geometry.
# No Blender needed; numpy is required (Blender ships it).
#
# A .zone lists the models it uses (section C6A5905E: N asset ids, then N u32s) and one 320-byte record
# per placed object (section 6987F172 holds each record's offset into section 06ABCAB2):
#     +0    4 x 4 float matrix, rows: X axis, Y axis, Z axis, translation   (game space, Y up)
#     +64   the model's bounding sphere and box (copied from the model)
#     +272  u32 index into the zone's model list
# Models are decoded straight from this build's layout (meshlets, packed tangent frames), LOD0 only.
import struct

import numpy as np

SEC_ZONE_MODELS = 0xC6A5905E
SEC_ZONE_INSTANCE_OFFSETS = 0x6987F172
SEC_ZONE_INSTANCE_DATA = 0x06ABCAB2

SEC_MODEL_BUILT = 0x283D0383
SEC_MODEL_SUBSETS = 0x78D9CBDE
SEC_MODEL_MATERIALS = 0x3250BB80
ROW = 128
FLAG_SKINNED = 0x1
FLAG_ORIGIN_OFFSET = 0x4000


class LevelError(Exception):
    pass


def _dat1(data):
    base = data.find(b'1TAD', 0, 1 << 16)
    if base < 0:
        raise LevelError('not a DAT1 file')
    d = memoryview(data)[base:]
    count = struct.unpack_from('<H', d, 12)[0]
    secs = {}
    for k in range(count):
        tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
        secs[tag] = (off, size)
    dsize = struct.unpack_from('<I', d, 8)[0]
    return d, secs, dsize


# ------------------------------------------------------------------------------------------- zones

def read_zone(data):
    """Returns (model_ids, instances); instances = [(model_index, 4x4 numpy matrix, game space, rows)]."""
    d, secs, _ = _dat1(data)
    if SEC_ZONE_MODELS not in secs or SEC_ZONE_INSTANCE_OFFSETS not in secs or SEC_ZONE_INSTANCE_DATA not in secs:
        return [], []
    mo, ms = secs[SEC_ZONE_MODELS]
    n = ms // 12
    ids = [int(x) for x in np.frombuffer(d, dtype='<u8', count=n, offset=mo)]
    oo, os_ = secs[SEC_ZONE_INSTANCE_OFFSETS]
    offs = np.frombuffer(d, dtype='<u4', count=os_ // 4, offset=oo)
    bo, bs = secs[SEC_ZONE_INSTANCE_DATA]
    out = []
    for off in offs:
        o = bo + int(off)
        if o + 276 > bo + bs:
            continue
        idx = struct.unpack_from('<I', d, o + 272)[0]
        if idx >= n:
            continue
        m = np.array(struct.unpack_from('<16f', d, o), dtype=np.float64).reshape(4, 4)
        m[:3, 3] = 0.0
        m[3, 3] = 1.0
        if not np.all(np.isfinite(m)):
            continue
        out.append((idx, m))
    return ids, out


# ------------------------------------------------------------------------------------------ models

def _meshlets(geo, start, count, nverts_total):
    """Expand meshlets to a (T, 3) int array of vertex indices."""
    headers = np.frombuffer(geo, dtype='<u4', count=count, offset=start)
    data = start + 24 * count
    tris = []
    for h in headers.tolist():
        unit = h & 0xFFFF
        nv = ((h >> 17) & 0x7F) + 1
        nt = (h >> 24) + 1
        p = data + unit * 16
        t = np.frombuffer(geo, dtype='<u2', count=nt, offset=p).astype(np.int32)
        v = np.frombuffer(geo, dtype='<u2', count=nv, offset=p + 2 * nt).astype(np.int32)
        local = np.stack([t & 31, (t >> 5) & 31, (t >> 10) & 31], axis=1)
        if local.max() >= nv:
            raise LevelError('damaged meshlet')
        tris.append(v[local])
    if not tris:
        return np.zeros((0, 3), dtype=np.int32)
    t = np.concatenate(tris)
    if t.size and t.max() >= nverts_total:
        raise LevelError('triangle refers to a missing vertex')
    return t


def _frames(words):
    """Packed tangent-frame quaternions -> unit normals (N, 3), game space."""
    p = np.stack([(words & 1023), ((words >> 10) & 1023), ((words >> 20) & 1023)], axis=1).astype(np.float64) / 511.5 - 1.0
    s2 = (p * p).sum(axis=1)
    k = 2.0 / (1.0 + s2)
    x, y, z = p[:, 0] * k, p[:, 1] * k, p[:, 2] * k
    w = (1.0 - s2) / (1.0 + s2)
    n = np.stack([2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)], axis=1)
    ln = np.linalg.norm(n, axis=1, keepdims=True)
    ln[ln == 0] = 1.0
    return n / ln


class StaticModel:
    """LOD0 geometry of a model: parts = [(material_index, positions (N,3), normals (N,3), uvs (N,2), triangles (T,3))]."""

    def __init__(self, part0, part1=None):
        d, secs, dsize = _dat1(part0)
        if SEC_MODEL_SUBSETS not in secs:
            raise LevelError('not a model')
        self.materials = []
        if SEC_MODEL_MATERIALS in secs:
            o, s = secs[SEC_MODEL_MATERIALS]
            for i in range(s // 32):
                p = struct.unpack_from('<I', d, o + 16 * i)[0]
                end = bytes(d[p:p + 512]).find(b'\0')
                self.materials.append(bytes(d[p:p + max(end, 0)]).decode('latin1').replace('\\', '/') if end > 0 else '')
        so, ss = secs[SEC_MODEL_SUBSETS]
        rows = [struct.unpack_from('<32I', d, so + ROW * k) for k in range(ss // ROW)]
        tail = bytes(d[dsize:])
        rows_len = max((r[22] + r[23] for r in rows), default=0)
        if part1 is not None:
            p1 = bytes(part1)
            streamed = [r for r in rows if (r[25] >> 16) == 1]
            base = min((r[22] for r in streamed), default=None)
            if base is None or max(r[22] + r[23] for r in streamed) - base != len(p1):
                base = rows_len - len(p1)
            geo = tail[:base] + p1
        else:
            geo = tail
        lod = [k for k, r in enumerate(rows) if (r[25] >> 16) & 1 or (r[25] >> 16) == 0]
        if not lod:
            masks = [r[25] >> 16 for r in rows if r[25] >> 16]
            best = min(m & -m for m in masks) if masks else 0
            lod = [k for k, r in enumerate(rows) if (r[25] >> 16) & best]
        self.parts = []
        for k in lod:
            r = rows[k]
            idx_count, vtx_count, idx_off = r[0], r[1], r[3]
            meshlets = r[4] & 0xFFFF
            flags = r[6] & 0xFFFF
            if not idx_count or not vtx_count or not meshlets:
                continue
            base_off, std = r[22], r[16]
            if base_off + std + 16 * vtx_count > len(geo) or base_off + idx_off + 24 * meshlets > len(geo):
                raise LevelError('model geometry is incomplete (is the streamed half missing?)')
            mpu = struct.unpack_from('<f', bytes(struct.pack('<I', r[7])))[0]
            if not np.isfinite(mpu) or mpu <= 0:
                mpu = 1.0 / 4096
            vb = np.frombuffer(geo, dtype='<i2', count=vtx_count * 8, offset=base_off + std).reshape(vtx_count, 8)
            pos = vb[:, :3].astype(np.float64) * mpu
            if flags & FLAG_ORIGIN_OFFSET:
                packed = struct.unpack_from('<iii', bytes(struct.pack('<3I', r[12], r[13], r[14])))
                sc = 256.0 * mpu
                pos += np.array([((v & 0xFFFF) ^ 0x8000) - 0x8000 for v in packed], dtype=np.float64) * sc
            words = np.frombuffer(geo, dtype='<u4', count=vtx_count * 4, offset=base_off + std).reshape(vtx_count, 4)[:, 2]
            nrm = _frames(words.astype(np.int64))
            uv = vb[:, 6:8].astype(np.float64) / 16384.0
            tris = _meshlets(geo, base_off + idx_off, meshlets, vtx_count)
            self.parts.append((r[8] & 0xFFFF, pos, nrm, uv, tris))
        self.skinned = any(rows[k][6] & FLAG_SKINNED for k in lod)


def game_to_blender_matrix(m):
    """Row-vector game matrix (Y up) -> column-vector Blender matrix (Z up), as nested lists."""
    c = np.array([[1, 0, 0, 0], [0, 0, -1, 0], [0, 1, 0, 0], [0, 0, 0, 1]], dtype=np.float64)   # game -> blender
    return (c @ m.T @ c.T).tolist()


def game_to_blender_points(p):
    return np.stack([p[:, 0], -p[:, 2], p[:, 1]], axis=1)
