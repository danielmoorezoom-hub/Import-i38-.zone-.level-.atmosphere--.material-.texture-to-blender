# Builds Blender scenes from Marvel's Wolverine level zones: every placed model becomes an object that
# shares its mesh with the other copies of the same model, placed with the zone's own transform.
import os

import bpy
import numpy as np
from mathutils import Matrix

from . import gamefiles, level


_MATS = {}


def _material(path):
    """One Blender material per game material path, shared by every model that uses it."""
    key = gamefiles.normalize(path)
    m = _MATS.get(key)
    try:
        if m is not None and m.name:
            return m
    except ReferenceError:
        pass
    for m in bpy.data.materials:
        if gamefiles.normalize(str(m.get("engine_material_path", ""))) == key:
            _MATS[key] = m
            return m
    name = path.replace("/", "\\")
    m = bpy.data.materials.new(name)
    m["engine_material_path"] = name
    _MATS[key] = m
    try:
        m.engine_material_path = name          # the Luna Engine IO add-on's property, when installed
    except (AttributeError, TypeError):
        pass
    return m


RT_ONLY = ("_rt_only", "rt_only.", "raytrace_only", "rtonly")


def is_rt_only(path):
    """Materials of geometry that only feeds ray-traced reflections and shadows (a coarse shell around trees)."""
    p = path.lower()
    return any(h in p for h in RT_ONLY)


def build_mesh(model, name, skip_rt_only=True):
    """StaticModel -> bpy mesh (all LOD0 parts merged, one material slot per game material)."""
    verts, norms, uvs, tris, mat_of_tri = [], [], [], [], []
    slots = []
    base = 0
    for mat_index, pos, nrm, uv, t in model.parts:
        path = model.materials[mat_index] if mat_index < len(model.materials) else ""
        if skip_rt_only and is_rt_only(path):
            continue
        if path not in slots:
            slots.append(path)
        verts.append(level.game_to_blender_points(pos))
        norms.append(level.game_to_blender_points(nrm))
        uvs.append(uv)
        tris.append(t + base)
        mat_of_tri.append(np.full(len(t), slots.index(path), dtype=np.int32))
        base += len(pos)
    me = bpy.data.meshes.new(name)
    if not verts:
        return me
    v = np.concatenate(verts).astype(np.float32)
    n = np.concatenate(norms).astype(np.float32)
    uv = np.concatenate(uvs).astype(np.float32)
    t = np.concatenate(tris).astype(np.int32)
    mt = np.concatenate(mat_of_tri)
    me.vertices.add(len(v))
    me.vertices.foreach_set("co", v.ravel())
    me.loops.add(len(t) * 3)
    me.loops.foreach_set("vertex_index", t.ravel())
    me.polygons.add(len(t))
    me.polygons.foreach_set("loop_start", np.arange(0, len(t) * 3, 3, dtype=np.int32))
    me.polygons.foreach_set("material_index", mt)
    me.polygons.foreach_set("use_smooth", np.ones(len(t), dtype=bool))
    layer = me.uv_layers.new(name="UVMap")
    loop_uv = uv[t.ravel()]
    loop_uv[:, 1] = 1.0 - loop_uv[:, 1]
    layer.data.foreach_set("uv", loop_uv.ravel())
    for path in slots:
        me.materials.append(_material(path) if path else None)
    me.validate(clean_customdata=False)
    me.update()
    try:
        me.normals_split_custom_set_from_vertices(n.tolist())
    except Exception:
        pass
    return me


class ZoneImporter:
    def __init__(self, sources, names=None, report=None):
        self.sources = sources
        self.game = sources.game()
        self.names = names
        self.report = report
        self.meshes = {}            # model id -> mesh or None
        self.log = []
        self.count = {"zones": 0, "objects": 0, "models": 0, "failed": 0, "missing": 0, "skipped": 0}

    def model_name(self, aid):
        p = self.names.name(aid) if self.names else None
        return os.path.splitext(os.path.basename(p.replace("\\", "/")))[0] if p else "model_%016X" % aid

    def mesh(self, aid, skip_skinned):
        if aid in self.meshes:
            return self.meshes[aid]
        me = None
        for existing in bpy.data.meshes:
            if existing.get("wolverine_model_id") == "%016X" % aid:
                me = existing
                break
        if me is None:
            a = self.game.read_id(aid, 0)
            if a is None:
                self.count["missing"] += 1
                self.log.append("   model %016X is not in the game" % aid)
                self.meshes[aid] = None
                return None
            b = self.game.read_id(aid, 1)
            try:
                model = level.StaticModel(a, b)
            except (level.LevelError, ValueError, IndexError) as e:
                self.count["failed"] += 1
                self.log.append("   model %s could not be read: %s" % (self.model_name(aid), e))
                self.meshes[aid] = None
                return None
            if skip_skinned and model.skinned:
                self.count["skipped"] += 1
                self.meshes[aid] = None
                return None
            me = build_mesh(model, self.model_name(aid))
            me["wolverine_model_id"] = "%016X" % aid
            p = self.names.name(aid) if self.names else None
            if p:
                me["wolverine_model_path"] = p
            self.count["models"] += 1
        self.meshes[aid] = me
        return me

    def import_zone(self, data, zone_name, parent_collection, skip_skinned=False):
        ids, instances = level.read_zone(data)
        col = bpy.data.collections.new(zone_name)
        parent_collection.children.link(col)
        self.log.append("%s: %d placed objects using %d models" % (zone_name, len(instances), len(ids)))
        for idx, m in instances:
            me = self.mesh(ids[idx], skip_skinned)
            if me is None or not len(me.polygons):
                continue
            ob = bpy.data.objects.new(me.name, me)
            ob.matrix_world = Matrix(level.game_to_blender_matrix(m))
            col.objects.link(ob)
            self.count["objects"] += 1
        self.count["zones"] += 1
        return col
