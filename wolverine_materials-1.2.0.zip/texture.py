# Marvel's Wolverine (PS5, i38) .texture decoding. No Blender needed; numpy is used when present.
#
# A texture is two pieces: the ".texture" asset (a DAT1 header followed by the small mips) and an
# optional streamed ".hd.texture" piece holding the big mips. Put end to end they form one stream:
#
#     [4 KB tail block: every mip of 2 KB or less]  [remaining mips, smallest first]  [padding]
#
# Pixels are block-compressed (BC1/BC4/BC5/BC7) and the blocks inside each mip are not stored row by
# row: they are tiled in 4 KB units (16 x 16 blocks for 16-byte blocks, 32 x 16 for 8-byte blocks)
# with a fixed bit pattern inside the unit. This module undoes that for the largest mip and returns
# it as an ordinary DDS file.
#
# Can also be run on its own:   python texture.py FILE_OR_FOLDER [...] [--out-dir DIR]
import os
import struct
import sys

try:
    import numpy as _np
except Exception:          # plain Python fallback is slower but gives the same bytes
    _np = None

TEXTURE_HEADER = 0x4EDE3593
# DXGI format -> bytes per 4x4 block
BLOCK_BYTES = {70: 8, 71: 8, 72: 8, 79: 8, 80: 8, 81: 8,
               73: 16, 74: 16, 75: 16, 76: 16, 77: 16, 78: 16, 82: 16, 83: 16, 84: 16,
               94: 16, 95: 16, 96: 16, 97: 16, 98: 16, 99: 16}
SRGB_FORMATS = {72, 75, 78, 99, 29}
FORMAT_NAMES = {70: 'BC1', 71: 'BC1', 72: 'BC1 sRGB', 77: 'BC3', 78: 'BC3 sRGB', 79: 'BC4', 80: 'BC4', 81: 'BC4',
                82: 'BC5', 83: 'BC5', 84: 'BC5', 95: 'BC6H', 96: 'BC6H', 98: 'BC7', 99: 'BC7 sRGB',
                28: 'RGBA8', 29: 'RGBA8 sRGB'}
# which coordinate each address bit carries inside one 16 x 16-block tile, lowest bit first
TILE_PATTERN = {8: 'xyyxxyxy', 16: 'yyxxyxyx'}
TAIL_BLOCK = 4096
TAIL_SLOTS = (2048, 1536, 1280, 1024)     # where the 1st, 2nd, ... mip of the tail block starts


class TextureError(Exception):
    pass


def _tile_order(bpb):
    """order[y * 16 + x] = index of block (x, y) inside a tile"""
    order = [0] * 256
    for i in range(256):
        x = y = xb = yb = 0
        for bit, c in enumerate(TILE_PATTERN[bpb]):
            v = (i >> bit) & 1
            if c == 'x':
                x |= v << xb
                xb += 1
            else:
                y |= v << yb
                yb += 1
        order[y * 16 + x] = i
    return order


_ORDERS = {}


def unwrap(data):
    """Offset of the DAT1 container (DAT1GUI puts an 'STG' header in front of exported files)."""
    if data[:4] == b'1TAD':
        return 0
    i = data.find(b'1TAD', 0, 1 << 16)
    if i < 0:
        raise TextureError('not a texture file')
    return i


def parse_header(data):
    base = unwrap(data)
    d = data[base:]
    if len(d) < 28:
        raise TextureError('texture file is too short')
    dsize, count = struct.unpack_from('<IH', d, 8)
    for k in range(count):
        tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
        if tag == TEXTURE_HEADER and size >= 24:
            h = d[off:off + size]
            sd_len, hd_len, hw, hh, sw, sh, layers = struct.unpack_from('<IIHHHHH', h, 0)
            return {
                'sd_len': sd_len, 'hd_len': hd_len, 'hd_width': hw, 'hd_height': hh,
                'sd_width': sw, 'sd_height': sh, 'layers': layers,
                'kind': h[18] & 0x0F,          # 1 colour, 2 normal, 3 gloss + specular, 4 specular colour + gloss, 0 other
                'format': struct.unpack_from('<H', h, 20)[0],
                'sd_mips': h[22], 'hd_mips': h[23],
                'sd_data': d[dsize:dsize + sd_len],
            }
    raise TextureError('no texture header found')


def _untile(data, wb, hb, bpb):
    """tiled blocks of a wb x hb-block surface -> the same blocks row by row"""
    tw, th = (wb + 15) // 16, (hb + 15) // 16
    need = tw * th * 256 * bpb
    if len(data) < need:
        raise TextureError('texture data is shorter than expected')
    if bpb not in _ORDERS:
        _ORDERS[bpb] = _tile_order(bpb)
    order = _ORDERS[bpb]
    if _np is not None:
        a = _np.frombuffer(data, dtype=_np.uint8, count=need).reshape(th, tw, 256, bpb)
        lut = _np.array(order, dtype=_np.int64).reshape(16, 16)
        ys, xs = _np.mgrid[0:hb, 0:wb]
        return a[ys >> 4, xs >> 4, lut[ys & 15, xs & 15]].tobytes()
    out = []
    tile_bytes = 256 * bpb
    for ty in range(th):
        rows = [[] for _ in range(16)]
        for tx in range(tw):
            t = (ty * tw + tx) * tile_bytes
            cols = min(16, wb - tx * 16)
            for y in range(16):
                o = order[y * 16:y * 16 + cols]
                rows[y].append(b''.join([data[t + i * bpb:t + (i + 1) * bpb] for i in o]))
        for y in range(min(16, hb - ty * 16)):
            out.append(b''.join(rows[y]))
    return b''.join(out)


def top_mip(texture_file, hd_file=None):
    """Largest mip that the given pieces contain. Returns (header, width, height, row-ordered block bytes)."""
    f = parse_header(texture_file)
    fmt = f['format']
    if f['layers'] > 1:
        raise TextureError('texture arrays are not supported')
    if fmt not in BLOCK_BYTES:
        raise TextureError('pixel format %s is not supported' % FORMAT_NAMES.get(fmt, fmt))
    bpb = BLOCK_BYTES[fmt]
    have_hd = bool(hd_file) and f['hd_len'] > 0 and len(hd_file) >= f['hd_len']
    stream = f['sd_data'] + (bytes(hd_file[:f['hd_len']]) if have_hd else b'')
    levels = f['sd_mips'] + (f['hd_mips'] if have_hd else 0)
    w, h = (f['hd_width'], f['hd_height']) if have_hd else (f['sd_width'], f['sd_height'])
    if levels < 1 or w < 1 or h < 1:
        raise TextureError('texture has no image data')
    unit_w = 16 if bpb == 16 else 32                       # 4 KB unit, in blocks
    sizes = []                                             # per level, largest first: (wb, hb, stored bytes, in tail?)
    for i in range(levels):
        mw, mh = max(w >> i, 1), max(h >> i, 1)
        wb, hb = (mw + 3) // 4, (mh + 3) // 4
        in_tail = levels > 1 and wb * hb * bpb <= 2048
        stored = ((wb + unit_w - 1) // unit_w) * ((hb + 15) // 16) * TAIL_BLOCK
        sizes.append((wb, hb, stored, in_tail))
    wb, hb, _stored, top_in_tail = sizes[0]
    if top_in_tail:
        # the whole chain lives in the tail block; the largest mip takes the first slot
        if wb > 16 or hb > 16:
            raise TextureError('unusual texture shape is not supported')
        start = TAIL_SLOTS[0]
        if bpb not in _ORDERS:
            _ORDERS[bpb] = _tile_order(bpb)
        order = _ORDERS[bpb]
        rows = []
        for y in range(hb):
            rows.append(b''.join([stream[start + order[y * 16 + x] * bpb: start + (order[y * 16 + x] + 1) * bpb]
                                  for x in range(wb)]))
        raw = b''.join(rows)
        if len(raw) != wb * hb * bpb:
            raise TextureError('texture data is shorter than expected')
        return f, w, h, raw
    off = TAIL_BLOCK if any(s[3] for s in sizes) else 0
    off += sum(s[2] for s in sizes[1:] if not s[3])
    return f, w, h, _untile(stream[off:], wb, hb, bpb)


def dds_bytes(fmt, width, height, raw):
    """A single-mip DDS file with a DX10 header."""
    pitch = max(1, (width + 3) // 4) * max(1, (height + 3) // 4) * BLOCK_BYTES[fmt]
    head = struct.pack('<4sIIIIIII44x', b'DDS ', 124, 0x1 | 0x2 | 0x4 | 0x1000 | 0x80000, height, width, pitch, 0, 1)
    pixel_format = struct.pack('<II4sIIIII', 32, 0x4, b'DX10', 0, 0, 0, 0, 0)
    caps = struct.pack('<IIIII', 0x1000, 0, 0, 0, 0)
    dx10 = struct.pack('<IIIII', fmt, 3, 0, 1, 0)
    return head + pixel_format + caps + dx10 + raw


def to_dds(texture_file, hd_file=None):
    """Returns (dds bytes, info dict)."""
    f, w, h, raw = top_mip(texture_file, hd_file)
    info = {'width': w, 'height': h, 'format': f['format'], 'format_name': FORMAT_NAMES.get(f['format'], str(f['format'])),
            'srgb': f['format'] in SRGB_FORMATS, 'kind': f['kind'],
            'full_size': (f['hd_width'], f['hd_height']) if f['hd_len'] else (f['sd_width'], f['sd_height'])}
    return dds_bytes(f['format'], w, h, raw), info


def has_cutout_alpha(dds):
    """True if a BC1 texture uses its 1-bit transparency (cheap check, no decoding)."""
    fmt = struct.unpack_from('<I', dds, 128)[0]
    if fmt not in (70, 71, 72):
        return False
    data = dds[148:]
    step = max(8, (len(data) // 8 // 20000) * 8)      # sample up to ~20k blocks
    for i in range(0, len(data) - 7, step):
        c0, c1, bits = struct.unpack_from('<HHI', data, i)
        if c0 <= c1 and bits:
            b = bits
            while b:
                if b & 3 == 3:
                    return True
                b >>= 2
    return False


# ---------------------------------------------------------------------------- command line

def _convert_file(path, out_dir, root):
    low = path.lower()
    if low.endswith('.hd.texture') or not low.endswith('.texture'):
        return None
    hd_path = path[:-len('.texture')] + '.hd.texture'
    hd = open(hd_path, 'rb').read() if os.path.isfile(hd_path) else None
    dds, info = to_dds(open(path, 'rb').read(), hd)
    if out_dir:
        rel = os.path.relpath(path, root) if root else os.path.basename(path)
        out = os.path.join(out_dir, rel[:-len('.texture')] + '.dds')
    else:
        out = path[:-len('.texture')] + '.dds'
    os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    with open(out, 'wb') as fh:
        fh.write(dds)
    note = '' if hd or info['full_size'] == (info['width'], info['height']) else \
        '  (low resolution: the .hd.texture file is missing; full size is %dx%d)' % info['full_size']
    return '%s  %dx%d %s%s' % (out, info['width'], info['height'], info['format_name'], note)


def main(argv):
    out_dir = None
    paths = []
    it = iter(argv)
    for a in it:
        if a == '--out-dir':
            out_dir = next(it, None)
        else:
            paths.append(a)
    if not paths:
        print('usage: python texture.py FILE_OR_FOLDER [...] [--out-dir DIR]\n'
              'Converts .texture files (with their .hd.texture next to them) to .dds.')
        return 2
    done = failed = 0
    for p in paths:
        if os.path.isdir(p):
            files = [(os.path.join(r, f), p) for r, _, fs in os.walk(p) for f in fs]
        else:
            files = [(p, None)]
        for path, root in sorted(files):
            try:
                line = _convert_file(path, out_dir, root)
                if line:
                    print(line)
                    done += 1
            except (TextureError, OSError, struct.error) as e:
                if path.lower().endswith('.texture') and not path.lower().endswith('.hd.texture'):
                    print('FAILED %s: %s' % (path, e))
                    failed += 1
    print('\n%d converted, %d failed' % (done, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
