# Builds Blender node materials from parsed game materials.
#
# The game shades with a specular / gloss model:
#     _c  base colour (diffuse; black where the surface is metal)
#     _n  normal map, X and Y only (BC5); green points up, as Blender expects
#     _g  kind 3: R = gloss, G = specular level        kind 4: RGB = specular colour, A = gloss
# Blender's Principled BSDF is metal / roughness, so the node tree converts:
#     roughness = 1 - gloss * Glossiness
#     F0        = specular ^ 2.2                        (the texture stores it sRGB-encoded)
#     metallic  = F0 remapped from 0.08 .. 0.45
#     base      = mix(diffuse, F0 colour, metallic)
#     specular level (non-metals) = F0 / 0.08
import bpy

NORMAL_GROUP = 'Wolverine Normal XY'
SPEC_GROUP = 'Wolverine Specular Gloss'


def _socket(tree, name, in_out, kind):
    return tree.interface.new_socket(name=name, in_out=in_out, socket_type=kind)


def _math(tree, op, a=None, b=None, loc=(0, 0), clamp=False):
    n = tree.nodes.new('ShaderNodeMath')
    n.operation = op
    n.use_clamp = clamp
    n.location = loc
    for i, v in enumerate((a, b)):
        if v is None:
            continue
        if isinstance(v, (int, float)):
            n.inputs[i].default_value = v
        else:
            tree.links.new(v, n.inputs[i])
    return n.outputs[0]


def normal_group():
    """Colour (X, Y in red and green) -> colour with the blue channel rebuilt, ready for a Normal Map node."""
    g = bpy.data.node_groups.get(NORMAL_GROUP)
    if g:
        return g
    g = bpy.data.node_groups.new(NORMAL_GROUP, 'ShaderNodeTree')
    _socket(g, 'Color', 'INPUT', 'NodeSocketColor')
    _socket(g, 'Color', 'OUTPUT', 'NodeSocketColor')
    gin = g.nodes.new('NodeGroupInput'); gin.location = (-700, 0)
    gout = g.nodes.new('NodeGroupOutput'); gout.location = (500, 0)
    sep = g.nodes.new('ShaderNodeSeparateColor'); sep.location = (-520, 0)
    g.links.new(gin.outputs[0], sep.inputs[0])
    x = _math(g, 'MULTIPLY_ADD', sep.outputs[0], 2.0, (-340, 120)); x.node.inputs[2].default_value = -1.0
    y = _math(g, 'MULTIPLY_ADD', sep.outputs[1], 2.0, (-340, -60)); y.node.inputs[2].default_value = -1.0
    xx = _math(g, 'MULTIPLY', x, x, (-160, 120))
    yy = _math(g, 'MULTIPLY', y, y, (-160, -60))
    s = _math(g, 'ADD', xx, yy, (0, 30))
    one_minus = _math(g, 'SUBTRACT', 1.0, s, (150, 30), clamp=True)
    z = _math(g, 'SQRT', one_minus, None, (300, 30))
    zc = _math(g, 'MULTIPLY_ADD', z, 0.5, (300, -130)); zc.node.inputs[2].default_value = 0.5
    comb = g.nodes.new('ShaderNodeCombineColor'); comb.location = (300, 200)
    g.links.new(sep.outputs[0], comb.inputs[0])
    g.links.new(sep.outputs[1], comb.inputs[1])
    g.links.new(zc, comb.inputs[2])
    g.links.new(comb.outputs[0], gout.inputs[0])
    return g


def spec_group():
    """Diffuse + specular colour + gloss -> Principled inputs."""
    g = bpy.data.node_groups.get(SPEC_GROUP)
    if g:
        return g
    g = bpy.data.node_groups.new(SPEC_GROUP, 'ShaderNodeTree')
    _socket(g, 'Diffuse', 'INPUT', 'NodeSocketColor').default_value = (0.5, 0.5, 0.5, 1)
    _socket(g, 'Specular', 'INPUT', 'NodeSocketColor').default_value = (0.22, 0.22, 0.22, 1)
    gl = _socket(g, 'Gloss', 'INPUT', 'NodeSocketFloat'); gl.default_value = 0.3; gl.min_value = 0; gl.max_value = 1
    gs = _socket(g, 'Glossiness', 'INPUT', 'NodeSocketFloat'); gs.default_value = 1.0; gs.min_value = 0; gs.max_value = 4
    _socket(g, 'Base Color', 'OUTPUT', 'NodeSocketColor')
    _socket(g, 'Metallic', 'OUTPUT', 'NodeSocketFloat')
    _socket(g, 'Roughness', 'OUTPUT', 'NodeSocketFloat')
    _socket(g, 'Specular Level', 'OUTPUT', 'NodeSocketFloat')
    gin = g.nodes.new('NodeGroupInput'); gin.location = (-900, 0)
    gout = g.nodes.new('NodeGroupOutput'); gout.location = (500, 0)
    gamma = g.nodes.new('ShaderNodeGamma'); gamma.location = (-700, -80); gamma.inputs[1].default_value = 2.2
    g.links.new(gin.outputs['Specular'], gamma.inputs[0])
    sep = g.nodes.new('ShaderNodeSeparateColor'); sep.location = (-520, -80)
    g.links.new(gamma.outputs[0], sep.inputs[0])
    m1 = _math(g, 'MAXIMUM', sep.outputs[0], sep.outputs[1], (-340, -80))
    f0 = _math(g, 'MAXIMUM', m1, sep.outputs[2], (-180, -80))
    rng = g.nodes.new('ShaderNodeMapRange'); rng.location = (0, 60); rng.clamp = True
    rng.inputs['From Min'].default_value = 0.08
    rng.inputs['From Max'].default_value = 0.45
    g.links.new(f0, rng.inputs['Value'])
    mix = g.nodes.new('ShaderNodeMix'); mix.data_type = 'RGBA'; mix.location = (220, 260)
    g.links.new(rng.outputs['Result'], mix.inputs[0])       # Factor
    g.links.new(gin.outputs['Diffuse'], mix.inputs[6])      # A (colour)
    g.links.new(gamma.outputs[0], mix.inputs[7])            # B (colour)
    gloss = _math(g, 'MULTIPLY', gin.outputs['Gloss'], gin.outputs['Glossiness'], (-340, -300), clamp=True)
    rough = _math(g, 'SUBTRACT', 1.0, gloss, (-160, -300), clamp=True)
    level = _math(g, 'DIVIDE', f0, 0.08, (0, -160), clamp=True)
    g.links.new(mix.outputs[2], gout.inputs['Base Color'])
    g.links.new(rng.outputs['Result'], gout.inputs['Metallic'])
    g.links.new(rough, gout.inputs['Roughness'])
    g.links.new(level, gout.inputs['Specular Level'])
    return g


def _image_node(tree, image, label, loc, non_color):
    n = tree.nodes.new('ShaderNodeTexImage')
    n.image = image
    n.label = label
    n.location = loc
    if image is not None:
        try:
            image.colorspace_settings.name = 'Non-Color' if non_color else 'sRGB'
        except TypeError:
            pass
    return n


def build(mat, images, glossiness=1.0, tint=(1.0, 1.0, 1.0), use_alpha=False, skin=False, extra=()):
    """images: {'color': (image, info), 'normal': ..., 'gloss': ..., 'alpha': ...} (any may be missing).
    extra: [(label, image, info)] loaded but left unconnected."""
    if not mat.node_tree:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new('ShaderNodeOutputMaterial'); out.location = (500, 0)
    bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled'); bsdf.location = (200, 0)
    tree.links.new(bsdf.outputs[0], out.inputs[0])
    conv = tree.nodes.new('ShaderNodeGroup'); conv.node_tree = spec_group(); conv.location = (-80, 0)
    conv.label = 'Specular / gloss to metal / roughness'
    conv.inputs['Glossiness'].default_value = glossiness
    tree.links.new(conv.outputs['Base Color'], bsdf.inputs['Base Color'])
    tree.links.new(conv.outputs['Metallic'], bsdf.inputs['Metallic'])
    tree.links.new(conv.outputs['Roughness'], bsdf.inputs['Roughness'])
    if 'Specular IOR Level' in bsdf.inputs:
        tree.links.new(conv.outputs['Specular Level'], bsdf.inputs['Specular IOR Level'])

    color = images.get('color')
    tinted = any(abs(c - 1.0) > 1e-4 for c in tint)
    if color:
        n = _image_node(tree, color[0], 'Base colour (_c)', (-460, 300), not color[1]['srgb'])
        if tinted:
            mul = tree.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'
            mul.location = (-270, 300); mul.label = 'DiffuseColor tint'
            mul.inputs[0].default_value = 1.0
            mul.inputs[7].default_value = (tint[0], tint[1], tint[2], 1.0)
            tree.links.new(n.outputs['Color'], mul.inputs[6])
            tree.links.new(mul.outputs[2], conv.inputs['Diffuse'])
        else:
            tree.links.new(n.outputs['Color'], conv.inputs['Diffuse'])
        if use_alpha:
            tree.links.new(n.outputs['Alpha'], bsdf.inputs['Alpha'])
    elif tinted:
        conv.inputs['Diffuse'].default_value = (tint[0], tint[1], tint[2], 1.0)
    gloss = images.get('gloss')
    if gloss:
        n = _image_node(tree, gloss[0], 'Gloss / specular (_g)', (-460, 0), True)
        if gloss[1]['kind'] == 4:                       # RGB = specular colour, A = gloss
            tree.links.new(n.outputs['Color'], conv.inputs['Specular'])
            tree.links.new(n.outputs['Alpha'], conv.inputs['Gloss'])
        else:                                           # R = gloss, G = specular level
            sep = tree.nodes.new('ShaderNodeSeparateColor'); sep.location = (-270, -40)
            comb = tree.nodes.new('ShaderNodeCombineColor'); comb.location = (-270, -200)
            tree.links.new(n.outputs['Color'], sep.inputs[0])
            for i in range(3):
                tree.links.new(sep.outputs[1], comb.inputs[i])
            tree.links.new(comb.outputs[0], conv.inputs['Specular'])
            tree.links.new(sep.outputs[0], conv.inputs['Gloss'])
            conv.location = (-80, 60)
    normal = images.get('normal')
    if normal:
        n = _image_node(tree, normal[0], 'Normal (_n)', (-760, -340), True)
        fix = tree.nodes.new('ShaderNodeGroup'); fix.node_tree = normal_group(); fix.location = (-460, -340)
        nm = tree.nodes.new('ShaderNodeNormalMap'); nm.location = (-270, -340)
        tree.links.new(n.outputs['Color'], fix.inputs[0])
        tree.links.new(fix.outputs[0], nm.inputs['Color'])
        tree.links.new(nm.outputs['Normal'], bsdf.inputs['Normal'])
    alpha = images.get('alpha')
    if alpha:
        if alpha[1].get('channel') == 'A':
            n = _image_node(tree, alpha[0], 'Strand opacity (_x alpha)', (-460, 600), True)
            tree.links.new(n.outputs['Alpha'], bsdf.inputs['Alpha'])
        else:
            n = _image_node(tree, alpha[0], 'Alpha (_a)', (-460, 600), True)
            tree.links.new(n.outputs['Color'], bsdf.inputs['Alpha'])
        use_alpha = True
    if skin and 'Subsurface Weight' in bsdf.inputs:
        bsdf.inputs['Subsurface Weight'].default_value = 0.15
        bsdf.inputs['Subsurface Radius'].default_value = (1.0, 0.35, 0.2)
        bsdf.inputs['Subsurface Scale'].default_value = 0.01
    if use_alpha and hasattr(mat, 'surface_render_method'):
        mat.surface_render_method = 'DITHERED'
    y = 300
    for label, image, info in extra:
        _image_node(tree, image, label, (-1100, y), not info['srgb'])
        y -= 290
    if extra:
        frame = tree.nodes.new('NodeFrame')
        frame.label = 'Other textures of this material (not connected)'
        for n in tree.nodes:
            if n.type == 'TEX_IMAGE' and n.location.x < -1000:
                n.parent = frame


def hair_standin(mat, color):
    """A plain hair-coloured surface with fine streaks, for a hair wrap mesh shown in place of hair the
    model file does not contain."""
    if not mat.node_tree:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new('ShaderNodeOutputMaterial'); out.location = (500, 0)
    bsdf = tree.nodes.new('ShaderNodeBsdfPrincipled'); bsdf.location = (200, 0)
    tree.links.new(bsdf.outputs[0], out.inputs[0])
    bsdf.inputs['Roughness'].default_value = 0.45
    # streaks: noise stretched along one axis, darkening the colour a little in places
    coord = tree.nodes.new('ShaderNodeTexCoord'); coord.location = (-900, 0)
    mapping = tree.nodes.new('ShaderNodeMapping'); mapping.location = (-700, 0)
    mapping.inputs['Scale'].default_value = (60.0, 60.0, 4.0)
    noise = tree.nodes.new('ShaderNodeTexNoise'); noise.location = (-500, 0)
    noise.inputs['Scale'].default_value = 4.0
    noise.inputs['Detail'].default_value = 4.0
    ramp = tree.nodes.new('ShaderNodeMapRange'); ramp.location = (-300, 0)
    ramp.inputs['To Min'].default_value = 0.6
    ramp.inputs['To Max'].default_value = 1.25
    mul = tree.nodes.new('ShaderNodeMix'); mul.data_type = 'RGBA'; mul.blend_type = 'MULTIPLY'
    mul.location = (-80, 100); mul.inputs[0].default_value = 1.0
    mul.inputs[6].default_value = (color[0], color[1], color[2], 1.0)
    tree.links.new(coord.outputs['Object'], mapping.inputs['Vector'])
    tree.links.new(mapping.outputs['Vector'], noise.inputs['Vector'])
    tree.links.new(noise.outputs['Fac'], ramp.inputs['Value'])
    tree.links.new(ramp.outputs['Result'], mul.inputs[7])
    tree.links.new(mul.outputs[2], bsdf.inputs['Base Color'])
    if hasattr(mat, 'surface_render_method'):
        mat.surface_render_method = 'DITHERED'
    mat.diffuse_color = (color[0], color[1], color[2], 1.0)
