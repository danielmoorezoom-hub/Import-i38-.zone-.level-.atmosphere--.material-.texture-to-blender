# Finding asset files: either straight from the installed game (toc + archives) or from a folder of
# files exported with DAT1GUI. No Blender needed.
import array
import os
import struct
import sys


def _crc64_table():
    table = []
    for i in range(256):
        c = i
        for _ in range(8):
            c = (c >> 1) ^ 0xC96C5795D7870F42 if c & 1 else c >> 1
        table.append(c)
    return table


_T64 = _crc64_table()


def normalize(path):
    """Asset paths as the game hashes them: lower case, forward slashes, no leading or doubled
    slashes, and "folder/../" resolved. Materials store some texture paths in the untidy form."""
    parts = []
    for part in path.replace('\\', '/').lower().split('/'):
        if part in ('', '.'):
            continue
        if part == '..':
            if parts:
                parts.pop()
            continue
        parts.append(part)
    return '/'.join(parts)


def asset_id(path):
    c = 0xC96C5795D7870F42
    for ch in normalize(path).encode('latin1', 'replace'):
        c = _T64[(c ^ ch) & 0xFF] ^ (c >> 8)
    return (c >> 2) | 0x8000000000000000


class GameFolder:
    """The game's own archives, addressed by asset path."""

    def __init__(self, folder):
        self.folder = folder
        toc_path = os.path.join(folder, 'toc')
        if not os.path.isfile(toc_path):
            raise OSError('there is no "toc" file in %s' % folder)
        b = self.toc = open(toc_path, 'rb').read()
        if b[8:12] != b'1TAD':
            raise OSError('the toc file has an unexpected format')
        count = struct.unpack_from('<H', b, 20)[0]
        secs = {}
        for i in range(count):
            tag, off, size = struct.unpack_from('<3I', b, 24 + 12 * i)
            secs[tag] = (8 + off, size)
        for need in (0x506D7B8A, 0xEDE8ADA9, 0x398ABFF0, 0x65BCF461):
            if need not in secs:
                raise OSError('the toc file has an unexpected format')
        off, size = secs[0x506D7B8A]
        self.ids = array.array('Q')
        self.ids.frombytes(b[off:off + size - size % 8])
        if sys.byteorder != 'little':
            self.ids.byteswap()
        off, size = secs[0xEDE8ADA9]
        self.spans = [struct.unpack_from('<II', b, off + 8 * i) for i in range(size // 8)]
        self.arch_off = secs[0x398ABFF0][0]
        self.size_off = secs[0x65BCF461][0]
        self.files = {}

    def _find(self, aid, span):
        if span >= len(self.spans):
            return None
        lo, n = self.spans[span]
        hi = end = lo + n
        while lo < hi:
            mid = (lo + hi) // 2
            if self.ids[mid] < aid:
                lo = mid + 1
            else:
                hi = mid
        return lo if lo < end and self.ids[lo] == aid else None

    def read(self, path, span=0):
        """Bytes of an asset, or None if the game does not have it."""
        return self.read_id(asset_id(path), span)

    def read_id(self, aid, span=0):
        index = self._find(aid, span)
        if index is None:
            return None
        size, arch, off, _ = struct.unpack_from('<4I', self.toc, self.size_off + 16 * index)
        raw = self.toc[self.arch_off + 66 * arch:self.arch_off + 66 * arch + 64].split(b'\0')[0]
        name = raw.decode('latin1').replace('\\', '/')
        f = self.files.get(name)
        if f is None:
            f = self.files[name] = open(os.path.join(self.folder, *name.split('/')), 'rb')
        f.seek(off)
        return f.read(size)

    def close(self):
        for f in self.files.values():
            f.close()
        self.files = {}


class NameList:
    """Asset names from a DAT1GUI hashes.txt ("ID,path,..." per line), loaded on first use."""

    def __init__(self, path):
        self.path = path
        self._names = None

    def _load(self):
        if self._names is None:
            self._names = {}
            if self.path and os.path.isfile(self.path):
                with open(self.path, encoding='utf-8', errors='replace') as fh:
                    for line in fh:
                        parts = line.split(',', 2)
                        if len(parts) >= 2 and parts[1]:
                            try:
                                self._names[int(parts[0], 16)] = parts[1]
                            except ValueError:
                                pass
        return self._names

    def name(self, aid):
        return self._load().get(aid)

    def find(self, prefix, extension):
        """Paths starting with prefix (any slash style, any case) and ending with extension."""
        pre = normalize(prefix)
        out = []
        for p in self._load().values():
            n = normalize(p)
            if n.endswith(extension) and (n == pre or n.startswith(pre + '/') or n.startswith(pre)):
                out.append(p)
        return sorted(set(out), key=lambda p: normalize(p))


class ExportFolder:
    """A folder of files exported with DAT1GUI. Files are matched by name, then by how much of the
    asset path their own path ends with (exports rarely keep the full path)."""

    def __init__(self, folder):
        self.folder = folder
        self.by_name = {}
        for root, _dirs, files in os.walk(folder):
            for fn in files:
                low = fn.lower()
                if low.endswith(('.texture', '.material')):
                    self.by_name.setdefault(low, []).append(os.path.join(root, fn))

    def find(self, path):
        want = normalize(path)
        candidates = self.by_name.get(want.rsplit('/', 1)[-1])
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        parts = want.split('/')

        def score(candidate):
            have = normalize(candidate).split('/')
            n = 0
            while n < len(parts) and n < len(have) and parts[-1 - n] == have[-1 - n]:
                n += 1
            return n
        return max(candidates, key=score)

    def read(self, path, span=0):
        if span == 1:
            if not normalize(path).endswith('.texture'):
                return None
            path = path[:-len('.texture')] + '.hd.texture'
        found = self.find(path)
        if not found:
            return None
        with open(found, 'rb') as fh:
            return fh.read()

    def close(self):
        pass


class Sources:
    """Looks in the exported folder first, then in the game."""

    def __init__(self, export_folder='', game_folder=''):
        self.sources = []
        self.problems = []
        if export_folder:
            if os.path.isdir(export_folder):
                self.sources.append(ExportFolder(export_folder))
            else:
                self.problems.append('Exported files folder not found: %s' % export_folder)
        if game_folder:
            try:
                self.sources.append(GameFolder(game_folder))
            except OSError as e:
                self.problems.append('Game folder: %s' % e)

    def read(self, path, span=0):
        for src in self.sources:
            data = src.read(path, span)
            if data is not None:
                return data
        return None

    def game(self):
        for src in self.sources:
            if isinstance(src, GameFolder):
                return src
        return None

    def read_texture(self, path):
        """(texture bytes, hd bytes or None). Both pieces come from the same place."""
        for src in self.sources:
            data = src.read(path, 0)
            if data is not None:
                return data, src.read(path, 1)
        return None, None

    def close(self):
        for src in self.sources:
            src.close()
