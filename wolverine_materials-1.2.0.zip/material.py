# Marvel's Wolverine (PS5, i38) .material parsing. No Blender needed.
#
# A material names the shader graph it is built on and then lists what it sets on that graph:
# float parameters and textures, each keyed by the CRC-32 of the graph input's name. The names
# themselves are not stored, so only the inputs identified so far are listed below; a texture in an
# unknown slot is classified by its file-name suffix instead.
import re
import struct

SEC_HEADER = 0xE1275683
SEC_OVERRIDES = 0xF5260180
SEC_SHADER = 0xBBFC8900

# texture slots that mean the same thing in (almost) every graph
SLOT_BASE_COLOR = 0xABDAD780       # "BaseMap2D_Texture"
SLOT_NORMAL = 0x7AE34E7A           # "NormalMap2D_Texture"
SLOT_GLOSS = 0x1576D848            # "GlossMap2D_Texture"
SLOT_MASK = 0xE68930AC
SLOT_PALETTE = 0x1C12D5A6          # "Palette_Texture"
SLOT_DAMAGE_MASK = 0x16241519      # "DamageMask2D_Texture"
SLOT_ROLES = {SLOT_BASE_COLOR: 'color', SLOT_NORMAL: 'normal', SLOT_GLOSS: 'gloss', SLOT_MASK: 'mask'}
SUFFIX_ROLES = {'c': 'color', 'n': 'normal', 'g': 'gloss', 'm': 'mask', 'a': 'alpha'}

PARAM_GLOSSINESS = 0x24F4CA4C      # "Glossiness": multiplies the gloss texture
PARAM_DIFFUSE_COLOR = 0x4BAAD667   # "DiffuseColor": multiplies the base colour texture
PARAM_HAIR_ROOT_COLOR = 0xE5C535A0  # a dark hair colour some hair materials set instead (name unknown)
DEFAULT_HAIR_COLOR = (0.0865, 0.0482, 0.0203)   # the brown most hair materials use

MODEL_MATERIAL = 0x3250BB80         # "Model Material" block of a .model


def model_material_paths(data):
    """Material paths listed by a .model file (any of its LODs), in the order its meshes index them."""
    base = data.find(b'1TAD', 0, 1 << 16)
    if base < 0:
        return []
    d = data[base:]
    try:
        count = struct.unpack_from('<H', d, 12)[0]
        for k in range(count):
            tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
            if tag == MODEL_MATERIAL:
                out = []
                for i in range(size // 32):
                    p = struct.unpack_from('<I', d, off + 16 * i)[0]
                    end = d.find(b'\0', p, p + 512)
                    if end > p:
                        out.append(d[p:end].decode('latin1').replace('\\', '/'))
                return out
    except struct.error:
        pass
    return []


def hair_color(material):
    """The flat colour a hair material asks for, or None."""
    for key in (PARAM_DIFFUSE_COLOR, PARAM_HAIR_ROOT_COLOR):
        v = material['params'].get(key)
        if v and len(v) >= 3 and all(0.0 <= x <= 1.0 for x in v[:3]) and max(v[:3]) > 0.002:
            return tuple(v[:3])
    return None


def is_placeholder(texture_path):
    """The engine's stand-in textures (pink / black / white defaults) are not real surface data."""
    p = texture_path.lower().lstrip('/')
    return 'default_pink_shader' in p or '/default/default_' in p or p.startswith('required/textures/')


class MaterialError(Exception):
    pass


def suffix_of(texture_path):
    m = re.search(r'_([a-z0-9]+)\.texture$', texture_path.lower())
    return m.group(1) if m else ''


def parse(data):
    """Returns {'graph': str, 'own_shader': bool, 'textures': [(slot, path)], 'params': {hash: floats}, 'flags': {hash: int}}"""
    base = data.find(b'1TAD', 0, 1 << 16)
    if base < 0:
        raise MaterialError('not a material file')
    d = data[base:]
    try:
        count, fixups = struct.unpack_from('<HH', d, 12)
        secs = {}
        for k in range(count):
            tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
            secs[tag] = (off, size)
        fix = dict(struct.unpack_from('<II', d, 16 + 12 * count + 8 * k) for k in range(fixups))
        out = {'graph': '', 'own_shader': SEC_SHADER in secs, 'textures': [], 'params': {}, 'flags': {}}
        if SEC_HEADER in secs and secs[SEC_HEADER][0] in fix:
            a = fix[secs[SEC_HEADER][0]]
            out['graph'] = d[a:d.find(b'\0', a)].decode('latin1').replace('\\', '/')
        if SEC_OVERRIDES not in secs:
            return out
        o, size = secs[SEC_OVERRIDES]
        _size, nparams, values, nflags, flags, ntex, tex, strings = struct.unpack_from('<8I', d, o)
        for k in range(nparams):
            value_off, words, name = struct.unpack_from('<HHI', d, o + 40 + 8 * k)
            out['params'][name] = struct.unpack_from('<%df' % (words // 2), d, o + values + value_off)
        for k in range(nflags):
            value, name = struct.unpack_from('<II', d, o + flags + 8 * k)
            out['flags'][name] = value
        for k in range(ntex):
            string_off, slot = struct.unpack_from('<II', d, o + tex + 8 * k)
            a = o + strings + string_off
            end = d.find(b'\0', a)
            if a >= len(d) or end < 0:
                raise MaterialError('damaged material file')
            out['textures'].append((slot, d[a:end].decode('latin1').replace('\\', '/')))
        return out
    except struct.error:
        raise MaterialError('damaged material file')


def roles(material):
    """Picks the textures a standard surface needs. Returns ({role: path}, [(slot, path) not used])."""
    chosen = {}
    used = set()
    for slot, path in material['textures']:           # the well-known slots win
        role = SLOT_ROLES.get(slot)
        if role and role not in chosen and suffix_of(path) not in ('array',) and not is_placeholder(path):
            chosen[role] = path
            used.add((slot, path))
    for slot, path in material['textures']:           # otherwise go by the file name
        role = SUFFIX_ROLES.get(suffix_of(path))
        if role and role not in chosen and slot not in SLOT_ROLES and not is_placeholder(path):
            if role in ('color', 'normal', 'gloss') and ('underlayer' in path or 'dmg' in path or 'blood' in path
                                                         or 'detail' in path or 'default_' in path):
                continue                              # damage layers and detail maps are not the main surface
            chosen[role] = path
            used.add((slot, path))
    others = [(slot, path) for slot, path in material['textures'] if (slot, path) not in used]
    return chosen, others
