# Wolverine Materials - builds Blender materials and textures for models from Marvel's Wolverine (PS5, i38)
# that were imported with the Luna Engine IO add-on (after converting them with ModelCombine).
#
# The model importer leaves each Blender material empty but records the game material's path on it.
# This add-on reads that .material, converts the .texture files it uses to .dds, and builds a node tree.
# Files are taken from a folder of DAT1GUI exports and/or straight from the installed game.

bl_info = {
    "name": "Wolverine Materials",
    "author": "",
    "version": (1, 4, 1),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > Wolverine",
    "description": "Build materials and textures for imported Marvel's Wolverine models",
    "category": "Material",
}

import json
import math
import os
import re
import tempfile

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, StringProperty
from bpy.types import AddonPreferences, Operator, Panel

from . import atmosphere, gamefiles, material, nodes, texture


def atmosphere_label_short(path):
    name = gamefiles.normalize(str(path)).rsplit("/", 1)[-1]
    return name[:-len(".atmosphere")] if name.endswith(".atmosphere") else name
from bpy_extras.io_utils import ImportHelper

LOG_NAME = "Wolverine Materials Log"
LEVEL_LOG = "Wolverine Level Log"
HELPER_HINTS = ("invisible", "wrapmesh", "compshell", "shared_scalp", "scalp.materialgraph")
# names that suggest the colour texture's alpha is a cut-out mask (matched as whole-word-ish patterns, so that
# "brown", "furniture" or "cardboard" do not count)
ALPHA_HINTS = re.compile(r"hair|lash|eyebrow|(?<![a-z])brows?(?![a-z])|(?<![a-z])fur(?![a-z])|cutout|alpha_?test"
                         r"|foliage|(?<![a-z])lea(f|ves)(?![a-z])|decal")


def _prefs(context):
    return context.preferences.addons[__package__].preferences


def material_path(mat):
    """The game path recorded by the model importer, or '' if this is not a game material."""
    path = ""
    try:
        path = str(getattr(mat, "engine_material_path", "") or "")
    except Exception:
        path = ""
    if not path:
        path = str(mat.get("engine_material_path", "") or "")
    if not path:
        m = re.match(r"^(.*\.material)(\.\d+)?$", mat.name, re.I)
        path = m.group(1) if m else ""
    return path.replace("\\", "/")


def texture_folder(prefs):
    folder = prefs.texture_folder.strip()
    if folder:
        return bpy.path.abspath(folder)
    if bpy.data.filepath:
        return os.path.join(os.path.dirname(bpy.data.filepath), "wolverine_textures")
    return os.path.join(tempfile.gettempdir(), "wolverine_textures")


class _Builder:
    def __init__(self, prefs, report):
        self.prefs = prefs
        self.sources = gamefiles.Sources(bpy.path.abspath(prefs.export_folder.strip()) if prefs.export_folder.strip() else "",
                                         bpy.path.abspath(prefs.game_folder.strip()) if prefs.game_folder.strip() else "")
        self.out = texture_folder(prefs)
        self.images = {}         # texture path -> (image, info) or None
        self.log = []
        self.count = {"materials": 0, "no_file": 0, "textures": 0, "converted": 0, "missing_tex": 0, "low_res": 0,
                      "unsupported": 0, "hidden": 0, "standin": 0}
        self.report = report

    def hair_color_near(self, path):
        """Hair colour of the hair material closest to this material's folder (same character)."""
        folder = path.replace("\\", "/").lower().rsplit("/", 1)[0]
        best = None
        for m in bpy.data.materials:
            p = material_path(m).replace("\\", "/").lower()
            if "hair" not in p or "wrapmesh" in p:
                continue
            common = len(os.path.commonprefix([folder, p]))
            if best is None or common > best[0]:
                best = (common, p, material_path(m))
        if best:
            data = self.sources.read(best[2], 0)
            if data is not None:
                try:
                    c = material.hair_color(material.parse(data))
                    if c:
                        return c
                except material.MaterialError:
                    pass
        return material.DEFAULT_HAIR_COLOR

    def note(self, text):
        self.log.append(text)

    def image(self, path):
        key = gamefiles.normalize(path)
        if key in self.images:
            return self.images[key]
        result = None
        try:
            result = self._load(path, key)
        except texture.TextureError as e:
            self.count["unsupported"] += 1
            self.note("   texture skipped (%s): %s" % (e, path))
        except (OSError, RuntimeError) as e:
            self.note("   could not save or load texture (%s): %s" % (str(e).strip(), path))
            self.count["unsupported"] += 1
        self.images[key] = result
        return result

    def _load(self, path, key):
        sd = hd = None
        for src in self.sources.sources:                 # prefer a source that has the high-resolution part too
            data = src.read(path, 0)
            if data is None:
                continue
            head = texture.parse_header(data)
            part = src.read(path, 1) if head["hd_len"] else None
            if sd is None or (part is not None and hd is None):
                sd, hd = data, part
            if not head["hd_len"] or part is not None:
                break
        if sd is None:
            self.count["missing_tex"] += 1
            self.note("   texture not found: %s" % path)
            return None
        head = texture.parse_header(sd)
        low = bool(head["hd_len"]) and hd is None
        rel = key[:-len(".texture")] if key.endswith(".texture") else key
        rel = re.sub(r"[^a-z0-9_./ -]", "_", rel).lstrip("./")
        dds_path = os.path.join(self.out, *rel.split("/")) + (".lowres.dds" if low else ".dds")
        png_path = dds_path[:-4] + ".png"
        final = png_path if self.prefs.save_png else dds_path
        dds, info = None, None
        if self.prefs.overwrite or not os.path.isfile(final):
            dds, info = texture.to_dds(sd, hd)
            os.makedirs(os.path.dirname(dds_path), exist_ok=True)
            with open(dds_path, "wb") as fh:
                fh.write(dds)
            self.count["converted"] += 1
        else:
            fmt = head["format"]
            info = {"format": fmt, "srgb": fmt in texture.SRGB_FORMATS, "kind": head["kind"],
                    "width": head["hd_width"] if hd is not None or not head["hd_len"] else head["sd_width"],
                    "height": head["hd_height"] if hd is not None or not head["hd_len"] else head["sd_height"]}
            if head["layers"] > 1 or fmt not in texture.BLOCK_BYTES:
                raise texture.TextureError("not supported")
        if low:
            self.count["low_res"] += 1
            self.note("   low resolution only (its .hd.texture was not found): %s" % path)
        info["cutout"] = False
        if info["format"] in (70, 71, 72):
            if dds is None and os.path.isfile(dds_path):
                with open(dds_path, "rb") as fh:
                    dds = fh.read()
            info["cutout"] = bool(dds) and texture.has_cutout_alpha(dds)
        if self.prefs.save_png and (dds is not None or not os.path.isfile(png_path)):
            tmp = bpy.data.images.load(dds_path, check_existing=False)
            if not tmp.has_data:
                tmp.pixels[0]                               # images load lazily; this forces it
            tmp.filepath_raw = png_path
            tmp.file_format = "PNG"
            tmp.save()
            bpy.data.images.remove(tmp)
            try:
                os.remove(dds_path)
            except OSError:
                pass
        img = bpy.data.images.load(final, check_existing=True)
        img.name = os.path.basename(final)
        self.count["textures"] += 1
        return img, info

    def build(self, mat):
        path = material_path(mat)
        data = self.sources.read(path, 0) if path else None
        if data is None:
            self.count["no_file"] += 1
            self.note("%s\n   material file not found" % (path or mat.name))
            return False
        try:
            parsed = material.parse(data)
        except material.MaterialError as e:
            self.count["no_file"] += 1
            self.note("%s\n   %s" % (path, e))
            return False
        self.note(path)
        chosen, others = material.roles(parsed)
        images = {}
        for role in ("color", "normal", "gloss", "alpha"):
            if role in chosen:
                got = self.image(chosen[role])
                if got:
                    images[role] = got
                    if role == "gloss":
                        got[0].alpha_mode = "CHANNEL_PACKED"
        graph = parsed["graph"].lower()
        is_hair = "hair" in graph and "wrapmesh" not in graph
        if is_hair and "alpha" not in images:
            # hair cards: the "_x" texture carries the strand opacity in its alpha channel (the same data as
            # "_a"); several materials name an "_a" that this build of the game does not include
            for _slot, tex_path in others:
                if material.suffix_of(tex_path) == "x":
                    got = self.image(tex_path)
                    if got:
                        got[0].alpha_mode = "CHANNEL_PACKED"
                        info = dict(got[1]); info["channel"] = "A"
                        images["alpha"] = (got[0], info)
                        chosen["alpha"] = tex_path
                        self.note("   strand opacity taken from the alpha channel of %s" % tex_path)
                        break
        extra = []
        if self.prefs.load_other_textures:
            for slot, tex_path in others:
                got = self.image(tex_path)
                if got:
                    extra.append(("%s  [slot %08X]" % (os.path.basename(tex_path), slot), got[0], got[1]))
        gloss_scale = parsed["params"].get(material.PARAM_GLOSSINESS, (1.0,))
        gloss_scale = gloss_scale[0] if gloss_scale and math.isfinite(gloss_scale[0]) else 1.0
        hint = (path + " " + parsed["graph"]).lower()
        use_alpha = "color" in images and (images["color"][1]["cutout"] or
                                           (ALPHA_HINTS.search(hint) is not None and images["color"][1]["format"] not in (70, 71, 72)))
        tint = parsed["params"].get(material.PARAM_DIFFUSE_COLOR, (1.0, 1.0, 1.0))
        tint = tuple(max(0.0, t) for t in tint[:3]) if len(tint) >= 3 and all(math.isfinite(t) for t in tint[:3]) else (1.0, 1.0, 1.0)
        if is_hair and "color" not in images:
            # no colour texture: the game colours this hair from a palette; use the material's flat hair colour
            tint = material.hair_color(parsed) or material.DEFAULT_HAIR_COLOR
        is_skin = "subsurface" in hint or "skin" in parsed["graph"].lower()
        nodes.build(mat, images, glossiness=max(0.0, min(4.0, gloss_scale)), tint=tint, use_alpha=use_alpha,
                    skin=is_skin, extra=extra)
        if is_hair and "alpha" in images:
            strand = None
            for _slot, tex_path in others + [(0, p) for p in chosen.values()]:
                if material.suffix_of(tex_path) == "x":
                    got = self.image(tex_path)
                    if got:
                        strand = got[0]
                        break
            hair_col = material.hair_color(parsed) or tint
            if min(hair_col[:3]) > 0.6:          # no real colour value (white default): never draw white hair
                hair_col = self.hair_color_near(path) if "color" not in images else (1.0, 1.0, 1.0)
            nodes.hair_cards(mat, hair_col, images["alpha"][0], images["alpha"][1].get("channel", "R"), strand,
                             gloss=max(0.0, min(1.0, gloss_scale)),
                             color_image=images["color"][0] if "color" in images else None)
            self.note("   hair cards: root-to-tip shading and sharper strands")
        if is_skin and "color" in images and self.prefs.lighten_hair_skin:
            got = self.image(chosen["mask"]) if "mask" in chosen else None
            hair = self.hair_color_near(path)
            skin_col = nodes.skin_tone(images["color"][0])
            if nodes.hair_covered_skin(mat, got[0] if got else None, hair, skin_col):
                self.note("   skin under the scalp and beard lifted towards the hair colour (as the game shows it)")
        mat["wolverine_graph"] = parsed["graph"]
        mat["wolverine_textures"] = json.dumps({"used": chosen, "other": [p for _s, p in others]}, indent=1)
        self.count["materials"] += 1
        if not images:
            self.note("   no usable textures; left as a plain surface")
        return True


def _is_helper(mat):
    name = material_path(mat).lower() + " " + str(mat.get("wolverine_graph", "")).lower()
    return any(h in name for h in HELPER_HINTS)


def _is_wrapmesh(mat):
    return "wrapmesh" in material_path(mat).lower() + " " + str(mat.get("wolverine_graph", "")).lower()


def _is_hair_cards(mat):
    graph = str(mat.get("wolverine_graph", "")).lower()
    name = graph or material_path(mat).lower()
    return "hair" in name and "wrapmesh" not in name and not _is_helper(mat)


def _root(obj):
    while obj.parent is not None:
        obj = obj.parent
    return obj


def _hair_standin_color(builder, root, members):
    """Colour for a wrap mesh shown as hair: taken from the model's hair material if it has one."""
    candidates = [material_path(s.material) for o in members for s in o.material_slots
                  if s.material and _is_hair_cards(s.material)]
    source = str(root.get("engine_model_source_path", "") or "")
    if source and os.path.isfile(source):
        try:
            with open(source, "rb") as fh:
                candidates += [p for p in material.model_material_paths(fh.read(1 << 20))
                               if "hair" in p.lower() and "wrapmesh" not in p.lower()]
        except OSError:
            pass
    for path in candidates:
        data = builder.sources.read(path, 0)
        if data is None:
            continue
        try:
            color = material.hair_color(material.parse(data))
        except material.MaterialError:
            continue
        if color:
            return color
    return material.DEFAULT_HAIR_COLOR


class WOLVERINE_OT_build_materials(Operator):
    bl_idname = "wolverine.build_materials"
    bl_label = "Build Game Materials"
    bl_description = "Read each imported material's .material file, convert its textures and build the Blender material"
    bl_options = {"REGISTER", "UNDO"}

    scope: EnumProperty(name="Objects", items=(("SELECTED", "Selected", "Selected objects and their children"),
                                               ("ALL", "All", "Every object in the file")), default="ALL")

    def execute(self, context):
        prefs = _prefs(context)
        if not prefs.export_folder.strip() and not prefs.game_folder.strip():
            self.report({"ERROR"}, "Set the game folder or the exported files folder first (sidebar > Wolverine).")
            return {"CANCELLED"}
        builder = _Builder(prefs, self.report)
        if not builder.sources.sources:
            self.report({"ERROR"}, "; ".join(builder.sources.problems) or "No usable folder set.")
            return {"CANCELLED"}

        if self.scope == "SELECTED":
            objs = set()
            for o in context.selected_objects:
                objs.add(o)
                objs.update(o.children_recursive)
        else:
            objs = set(bpy.data.objects)
        mats = []
        for o in objs:
            if o.type != "MESH":
                continue
            for slot in o.material_slots:
                if slot.material and slot.material not in mats and material_path(slot.material):
                    mats.append(slot.material)
        if not mats:
            self.report({"WARNING"}, "No imported game materials found on these objects.")
            return {"CANCELLED"}

        wm = context.window_manager
        wm.progress_begin(0, len(mats))
        try:
            for i, mat in enumerate(sorted(mats, key=lambda m: m.name)):
                builder.build(mat)
                wm.progress_update(i + 1)
        finally:
            wm.progress_end()
            builder.sources.close()

        if prefs.hide_helpers:
            # Hair wrap meshes are invisible shells in the game. Most heads also have hair cards at full
            # detail; some draw their full-detail hair with a strand system that is not in the model file,
            # and there the shell is the only hair there is, so it is kept and shaded as hair instead.
            groups = {}
            for o in objs:
                if o.type == "MESH":
                    groups.setdefault(_root(o), set()).add(o)
            for root, members in groups.items():
                family = [o for o in ([root] + list(root.children_recursive)) if o.type == "MESH"]
                has_cards = any(not o.hide_render and s.material and _is_hair_cards(s.material)
                                for o in family for s in o.material_slots)
                for o in members:
                    if not o.material_slots or not all(s.material and _is_helper(s.material) for s in o.material_slots):
                        continue
                    if not has_cards and all(_is_wrapmesh(s.material) for s in o.material_slots):
                        color = _hair_standin_color(builder, root, family)
                        for s in o.material_slots:
                            nodes.hair_standin(s.material, color)
                        o.hide_render = False
                        try:
                            o.hide_set(False)
                        except RuntimeError:
                            o.hide_viewport = False
                        builder.count["standin"] += 1
                        builder.note("%s: this model has no hair cards at full detail (the game draws that hair "
                                     "separately), so its hair wrap mesh is shown as a plain hair-coloured stand-in. "
                                     "Models converted with ModelCombine 1.2 or later include the hair cards." % o.name)
                        continue
                    if not o.hide_render:
                        builder.count["hidden"] += 1
                    o.hide_render = True
                    try:
                        o.hide_set(True)
                    except RuntimeError:
                        o.hide_viewport = True

        builder.sources.close()
        c = builder.count
        summary = "%d materials built, %d textures (%d newly converted)" % (c["materials"], c["textures"], c["converted"])
        problems = []
        if c["no_file"]:
            problems.append("%d materials not found" % c["no_file"])
        if c["missing_tex"]:
            problems.append("%d textures not found" % c["missing_tex"])
        if c["low_res"]:
            problems.append("%d low-resolution only" % c["low_res"])
        if c["unsupported"]:
            problems.append("%d textures of unsupported kinds skipped" % c["unsupported"])
        text = bpy.data.texts.get(LOG_NAME) or bpy.data.texts.new(LOG_NAME)
        text.clear()
        text.write(summary + ("\nProblems: " + ", ".join(problems) if problems else "") + "\n")
        text.write("Textures were saved in: %s\n\n" % builder.out)
        text.write("\n".join(builder.log) + "\n")
        if c["hidden"]:
            summary += ", %d helper meshes hidden" % c["hidden"]
        if c["standin"]:
            summary += ", %d hair wrap mesh(es) shown as stand-in hair" % c["standin"]
        if problems:
            self.report({"WARNING"}, summary + ". " + ", ".join(problems) + ' (details in the text "%s")' % LOG_NAME)
        else:
            self.report({"INFO"}, summary + ".")
        return {"FINISHED"}


class WOLVERINE_Preferences(AddonPreferences):
    bl_idname = __package__

    game_folder: StringProperty(
        name="Game folder", subtype="DIR_PATH",
        description="The installed game folder that contains the 'toc' file (for example ...\\PPSA03671-app0). "
                    "Materials and textures are read straight from it, so nothing has to be exported first")
    export_folder: StringProperty(
        name="Exported files", subtype="DIR_PATH",
        description="Optional: a folder of .material / .texture / .hd.texture files exported with DAT1GUI. "
                    "Looked in first; anything missing is taken from the game folder")
    texture_folder: StringProperty(
        name="Save textures in", subtype="DIR_PATH",
        description="Where converted textures are written. Empty: a 'wolverine_textures' folder next to the .blend "
                    "file (or the temporary folder if the file is not saved yet)")
    save_png: BoolProperty(name="Save as PNG instead of DDS", default=False,
                           description="Slower and larger, but readable by any program")
    overwrite: BoolProperty(name="Convert again even if already there", default=False)
    load_other_textures: BoolProperty(
        name="Also load unused textures", default=False,
        description="Add a material's other textures (masks, damage layers, detail maps) as unconnected image nodes")
    lighten_hair_skin: BoolProperty(
        name="Lighten skin under hair",
        description="Head textures paint the scalp and beard area almost black (in the game strands and a scalp "
                    "layer cover it). Lighten it to a mix of the skin and hair colour",
        default=True)
    hide_helpers: BoolProperty(
        name="Hide invisible helper meshes", default=True,
        description="Hide meshes whose material is an invisible helper (hair wrap mesh, compression shell)")
    hashes_file: StringProperty(
        name="Asset names (hashes.txt)", subtype="FILE_PATH",
        description="Optional: DAT1GUI's hashes.txt. Gives imported level objects their model names and lets you "
                    "import every zone in a folder at once")

    def draw(self, context):
        draw_settings(self.layout, self)


def draw_settings(layout, prefs):
    col = layout.column()
    col.prop(prefs, "game_folder")
    col.prop(prefs, "export_folder")
    col.prop(prefs, "texture_folder")
    col.prop(prefs, "hashes_file")
    col = layout.column(align=True)
    col.prop(prefs, "hide_helpers")
    col.prop(prefs, "lighten_hair_skin")
    col.prop(prefs, "load_other_textures")
    col.prop(prefs, "save_png")
    col.prop(prefs, "overwrite")


class WOLVERINE_PT_panel(Panel):
    bl_label = "Wolverine Materials"
    bl_idname = "WOLVERINE_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Wolverine"

    def draw(self, context):
        layout = self.layout
        prefs = _prefs(context)
        draw_settings(layout, prefs)
        if not prefs.game_folder.strip() and not prefs.export_folder.strip():
            layout.label(text="Set the game folder first", icon="INFO")
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator(WOLVERINE_OT_build_materials.bl_idname, text="Build for All").scope = "ALL"
        row.operator(WOLVERINE_OT_build_materials.bl_idname, text="Selected Only").scope = "SELECTED"
        if LOG_NAME in bpy.data.texts:
            layout.label(text='Details: text "%s"' % LOG_NAME, icon="TEXT")


# ------------------------------------------------------------------------------------------ levels

def _zone_label(path):
    return gamefiles.normalize(path).rsplit("/", 1)[-1]


def run_zone_import(context, prefs, zones, report, build=True, include_impostors=False, skip_skinned=False):
    """zones: list of (label, bytes). Returns the created collections."""
    from . import level_import
    sources = gamefiles.Sources("", bpy.path.abspath(prefs.game_folder.strip()) if prefs.game_folder.strip() else "")
    if sources.game() is None:
        report({"ERROR"}, "Set the game folder first (sidebar > Wolverine); level models are read from it.")
        return None
    names = gamefiles.NameList(bpy.path.abspath(prefs.hashes_file.strip())) if prefs.hashes_file.strip() else None
    imp = level_import.ZoneImporter(sources, names, report)
    root = bpy.data.collections.new("Wolverine level" if len(zones) > 1 else "Wolverine " + zones[0][0])
    context.scene.collection.children.link(root)
    wm = context.window_manager
    wm.progress_begin(0, len(zones))
    created = []
    try:
        for i, (label, data) in enumerate(zones):
            try:
                created.append(imp.import_zone(data, label, root, skip_skinned))
            except Exception as e:     # one bad zone should not stop the rest
                imp.log.append("%s: could not be read (%s)" % (label, e))
            wm.progress_update(i + 1)
    finally:
        wm.progress_end()
        sources.close()
    c = imp.count
    text = bpy.data.texts.get(LEVEL_LOG) or bpy.data.texts.new(LEVEL_LOG)
    text.clear()
    text.write("%d zones, %d objects, %d models\n" % (c["zones"], c["objects"], c["models"]))
    text.write("\n".join(imp.log) + "\n")
    summary = "%d objects placed from %d models in %d zone(s)" % (c["objects"], c["models"], c["zones"])
    if c["missing"] or c["failed"]:
        summary += " (%d models missing, %d unreadable; see the text \"%s\")" % (c["missing"], c["failed"], LEVEL_LOG)
    if build and c["objects"]:
        for ob in context.view_layer.objects:
            ob.select_set(False)
        objs = list(root.all_objects)
        for ob in objs:
            try:
                ob.select_set(True)
            except RuntimeError:
                pass
        if objs:
            context.view_layer.objects.active = objs[0]
        bpy.ops.wolverine.build_materials(scope="SELECTED")
    report({"INFO"}, summary)
    return root


class WOLVERINE_OT_import_zone(Operator):
    bl_idname = "wolverine.import_zone"
    bl_label = "Import Level Zone"
    bl_description = ("Place every model of a level zone (or of all zones in a folder) in the scene, read straight "
                      "from the game")
    bl_options = {"REGISTER", "UNDO"}

    zone: StringProperty(name="Zone or folder", description="Asset path of a .zone (as DAT1GUI shows it), or a folder "
                         "of zones such as levels/i33/openarea/telambang/tile_h12 (folders need the hashes.txt setting)")
    include_impostors: BoolProperty(name="Include impostor zones", default=False,
                                    description="Impostor zones hold far-away stand-in geometry")
    build: BoolProperty(name="Build materials", default=True)
    skip_skinned: BoolProperty(name="Skip skinned models", default=False,
                               description="Leave out models that are normally animated (characters, flags, cables)")

    def execute(self, context):
        prefs = _prefs(context)
        target = self.zone.strip().strip('"')
        if not target:
            self.report({"ERROR"}, "Type the zone's asset path first.")
            return {"CANCELLED"}
        game_dir = bpy.path.abspath(prefs.game_folder.strip()) if prefs.game_folder.strip() else ""
        try:
            game = gamefiles.GameFolder(game_dir)
        except OSError as e:
            self.report({"ERROR"}, "Game folder: %s" % e)
            return {"CANCELLED"}
        zones = []
        try:
            if gamefiles.normalize(target).endswith(".zone"):
                data = game.read(target)
                if data is None:
                    self.report({"ERROR"}, "The game has no asset called %s" % target)
                    return {"CANCELLED"}
                zones.append((_zone_label(target), data))
            else:
                if not prefs.hashes_file.strip():
                    self.report({"ERROR"}, "Importing a whole folder needs the hashes.txt setting (sidebar > Wolverine).")
                    return {"CANCELLED"}
                names = gamefiles.NameList(bpy.path.abspath(prefs.hashes_file.strip()))
                found = [p for p in names.find(target, ".zone")
                         if self.include_impostors or "impostor" not in p.lower()]
                for p in found:
                    data = game.read(p)
                    if data is not None:
                        zones.append((_zone_label(p), data))
                if not zones:
                    self.report({"ERROR"}, "No zones found under %s" % target)
                    return {"CANCELLED"}
        finally:
            game.close()
        root = run_zone_import(context, prefs, zones, self.report, self.build, self.include_impostors, self.skip_skinned)
        return {"FINISHED"} if root else {"CANCELLED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=520)


class WOLVERINE_OT_import_zone_file(Operator, ImportHelper):
    bl_idname = "wolverine.import_zone_file"
    bl_label = "Import Wolverine Zone (.zone)"
    bl_description = "Import a .zone file exported with DAT1GUI; its models are read from the game folder"
    bl_options = {"REGISTER", "UNDO"}
    filename_ext = ".zone"
    filter_glob: StringProperty(default="*.zone", options={"HIDDEN"})
    build: BoolProperty(name="Build materials", default=True)
    skip_skinned: BoolProperty(name="Skip skinned models", default=False)

    def execute(self, context):
        prefs = _prefs(context)
        try:
            with open(self.filepath, "rb") as fh:
                data = fh.read()
        except OSError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        root = run_zone_import(context, prefs, [(os.path.basename(self.filepath), data)], self.report,
                               self.build, False, self.skip_skinned)
        return {"FINISHED"} if root else {"CANCELLED"}


# ------------------------------------------------------------------------------------------ atmospheres (sky)

def _atmosphere_list(prefs):
    found = set(atmosphere.KNOWN)
    if prefs.hashes_file.strip():
        try:
            found.update(gamefiles.NameList(bpy.path.abspath(prefs.hashes_file.strip())).find("atmosphere", ".atmosphere"))
        except OSError:
            pass
    return sorted(found, key=lambda p: gamefiles.normalize(p))


def _atmosphere_search(self, context, edit_text):
    words = edit_text.lower().split()
    return [p for p in _atmosphere_list(_prefs(context)) if all(w in p.lower() for w in words)]


class _AtmosphereOptions:
    add_sun: BoolProperty(name="Add sun lamp", default=True,
                          description="A Sun lamp with the atmosphere's key light colour, strength and direction")
    set_exposure: BoolProperty(name="Set exposure", default=True,
                               description="Set the scene's exposure so the average sky brightness lands a little below 1. The game's "
                                           "sky and sun values are in physical-style units and its own tone mapping does this")
    sky_strength: FloatProperty(name="Strength", default=1.0, min=0.0, soft_max=10.0,
                                description="Multiplies both the sky and the sun")
    mirror: BoolProperty(name="Mirror east-west", default=False,
                         description="Flip the sky and the sun around the game's X axis together, in case they look mirrored "
                                     "against imported level zones")


class WOLVERINE_OT_import_atmosphere(Operator, _AtmosphereOptions):
    bl_idname = "wolverine.import_atmosphere"
    bl_label = "Import Atmosphere (Sky)"
    bl_description = "Set the scene's world to a game atmosphere: its sky box texture, sky rotation and key light (sun)"
    bl_options = {"REGISTER", "UNDO"}

    atmosphere: StringProperty(name="Atmosphere", search=_atmosphere_search,
                               description="Asset path of an .atmosphere (type part of a name to search)")

    def execute(self, context):
        from . import atmosphere_import
        prefs = _prefs(context)
        target = self.atmosphere.strip().strip('"')
        if not target:
            self.report({"ERROR"}, "Pick an atmosphere first.")
            return {"CANCELLED"}
        game_dir = bpy.path.abspath(prefs.game_folder.strip()) if prefs.game_folder.strip() else ""
        try:
            game = gamefiles.GameFolder(game_dir)
        except OSError as e:
            self.report({"ERROR"}, "Game folder: %s" % e)
            return {"CANCELLED"}
        try:
            data = game.read(target)
        finally:
            game.close()
        if data is None:
            self.report({"ERROR"}, "The game has no asset called %s" % target)
            return {"CANCELLED"}
        world = atmosphere_import.run_import(context, prefs, target, data, texture_folder(prefs), self.report,
                                             self.add_sun, self.set_exposure, self.sky_strength, prefs.overwrite,
                                             self.mirror)
        return {"FINISHED"} if world else {"CANCELLED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=560)


class WOLVERINE_OT_import_atmosphere_file(Operator, ImportHelper, _AtmosphereOptions):
    bl_idname = "wolverine.import_atmosphere_file"
    bl_label = "Import Wolverine Atmosphere (.atmosphere)"
    bl_description = "Import an .atmosphere file exported with DAT1GUI; its sky texture is read from the game folder"
    bl_options = {"REGISTER", "UNDO"}
    filename_ext = ".atmosphere"
    filter_glob: StringProperty(default="*.atmosphere", options={"HIDDEN"})

    def execute(self, context):
        from . import atmosphere_import
        prefs = _prefs(context)
        try:
            with open(self.filepath, "rb") as fh:
                data = fh.read()
        except OSError as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        world = atmosphere_import.run_import(context, prefs, os.path.basename(self.filepath), data,
                                             texture_folder(prefs), self.report, self.add_sun, self.set_exposure,
                                             self.sky_strength, prefs.overwrite, self.mirror)
        return {"FINISHED"} if world else {"CANCELLED"}


def _menu_import(self, context):
    self.layout.operator(WOLVERINE_OT_import_zone_file.bl_idname, text="Wolverine Level Zone (.zone)")
    self.layout.operator(WOLVERINE_OT_import_atmosphere_file.bl_idname, text="Wolverine Atmosphere / Sky (.atmosphere)")


class WOLVERINE_PT_level(Panel):
    bl_label = "Wolverine Levels"
    bl_idname = "WOLVERINE_PT_level"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Wolverine"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Uses the game folder set above.")
        row = layout.row()
        row.scale_y = 1.4
        row.operator(WOLVERINE_OT_import_zone.bl_idname, text="Import Zone / Level...", icon="WORLD")
        layout.operator(WOLVERINE_OT_import_zone_file.bl_idname, text="Import exported .zone file...", icon="FILE")
        if LEVEL_LOG in bpy.data.texts:
            layout.label(text='Details: text "%s"' % LEVEL_LOG, icon="TEXT")
        layout.separator()
        row = layout.row()
        row.scale_y = 1.4
        row.operator(WOLVERINE_OT_import_atmosphere.bl_idname, text="Import Atmosphere (Sky)...", icon="LIGHT_SUN")
        layout.operator(WOLVERINE_OT_import_atmosphere_file.bl_idname, text="Import exported .atmosphere file...", icon="FILE")
        world = context.scene.world
        if world is not None and world.get("wolverine_atmosphere"):
            box = layout.box()
            box.label(text=atmosphere_label_short(world["wolverine_atmosphere"]), icon="WORLD")
            box.label(text="Sun: azimuth %.0f, elevation %.0f, intensity %.3g" % (
                world.get("wolverine_key_azimuth", 0), world.get("wolverine_key_elevation", 0), world.get("wolverine_key_intensity", 0)))


_CLASSES = (WOLVERINE_Preferences, WOLVERINE_OT_build_materials, WOLVERINE_PT_panel,
            WOLVERINE_OT_import_zone, WOLVERINE_OT_import_zone_file, WOLVERINE_OT_import_atmosphere,
            WOLVERINE_OT_import_atmosphere_file, WOLVERINE_PT_level)


def register():
    for cls in _CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_import.append(_menu_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(_menu_import)
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
